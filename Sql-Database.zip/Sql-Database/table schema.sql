
DROP DATABASE IF EXISTS lms;
CREATE DATABASE lms CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE lms;


CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE books (
  book_id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(150) NOT NULL,
  status ENUM('available','borrowed') DEFAULT 'available',
  borrower_id INT NULL,
  due_date DATE NULL,
  FOREIGN KEY (borrower_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE SET NULL
);


CREATE TABLE transactions (
  transaction_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  borrow_date DATE NOT NULL,
  due_date DATE NOT NULL,
  returned BOOLEAN DEFAULT 0,
  return_date DATE NULL,
  renew_count INT DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (book_id) REFERENCES books(book_id)
);


DELIMITER //
CREATE PROCEDURE sp_borrow(IN p_user_id INT, IN p_book_id INT, IN p_days INT)
BEGIN
  DECLARE v_status VARCHAR(10);
  SELECT status INTO v_status FROM books WHERE book_id = p_book_id;
  IF v_status = 'available' THEN
    UPDATE books
      SET status = 'borrowed', borrower_id = p_user_id, due_date = DATE_ADD(CURDATE(), INTERVAL p_days DAY)
      WHERE book_id = p_book_id;
    INSERT INTO transactions (user_id, book_id, borrow_date, due_date)
      VALUES (p_user_id, p_book_id, CURDATE(), DATE_ADD(CURDATE(), INTERVAL p_days DAY));
  END IF;
END //
DELIMITER ;


DELIMITER //
CREATE PROCEDURE sp_renew(IN p_book_id INT, IN p_extra_days INT)
BEGIN
  UPDATE books
    SET due_date = DATE_ADD(due_date, INTERVAL p_extra_days DAY)
    WHERE book_id = p_book_id AND status = 'borrowed';
  UPDATE transactions
    SET due_date = DATE_ADD(due_date, INTERVAL p_extra_days DAY), renew_count = renew_count + 1
    WHERE book_id = p_book_id AND returned = 0;
END //
DELIMITER ;