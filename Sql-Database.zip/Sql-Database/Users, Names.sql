
USE lms;


INSERT INTO users (name, email) VALUES
('Nourhan El Shorbagy', 'nourhanelshorbagy@gmail.com'),
('Rodaina Hassan', 'rodainahassan@gmail.com'),
('Farida Nasr', 'faridanasr@gmail.com'),
('Mariam Ali', 'mariamali@gmail.com'),
('Aya Mostafa', 'ayamostafa@gmail.com'),
('Mohamed Ahmed', 'mohamedahmed@gmail.com'),
('Omar Khaled', 'omarkhaled@gmail.com'),
('Youssef Mahmoud', 'youssefmahmoud@gmail.com'),
('Sara Fathi', 'sarafathi@gmail.com'),
('Layla Gamal', 'laylagamal@gmail.com');


INSERT INTO books (title, author, status, borrower_id, due_date) VALUES
('Clean Code', 'Robert C. Martin', 'borrowed', 1, DATE_ADD(CURDATE(), INTERVAL 7 DAY)),
('The Pragmatic Programmer', 'Andrew Hunt', 'available', NULL, NULL),
('Design Patterns', 'Erich Gamma', 'borrowed', 2, DATE_ADD(CURDATE(), INTERVAL 10 DAY)),
('Algorithms Unlocked', 'Thomas Cormen', 'available', NULL, NULL),
('Software Engineering', 'Ian Sommerville', 'available', NULL, NULL),
('Database System Concepts', 'Abraham Silberschatz', 'borrowed', 3, DATE_ADD(CURDATE(), INTERVAL 5 DAY)),
('Computer Networks', 'Andrew Tanenbaum', 'available', NULL, NULL),
('Operating Systems', 'Abraham Silberschatz', 'available', NULL, NULL),
('Code Complete', 'Steve McConnell', 'available', NULL, NULL),
('Programming Pearls', 'Jon Bentley', 'borrowed', 4, DATE_ADD(CURDATE(), INTERVAL 8 DAY)),
('Head First Design Patterns', 'Eric Freeman', 'available', NULL, NULL),
('Refactoring', 'Martin Fowler', 'available', NULL, NULL),
('You Don’t Know JS', 'Kyle Simpson', 'available', NULL, NULL),
('Python Crash Course', 'Eric Matthes', 'borrowed', 5, DATE_ADD(CURDATE(), INTERVAL 12 DAY)),
('Eloquent JavaScript', 'Marijn Haverbeke', 'available', NULL, NULL);


INSERT INTO transactions (user_id, book_id, borrow_date, due_date, returned, renew_count) VALUES
(1, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 7 DAY), 0, 0),
(2, 3, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 10 DAY), 0, 1),
(3, 6, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 1, 0),
(4, 10, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 8 DAY), 0, 0),
(5, 14, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 12 DAY), 0, 2);