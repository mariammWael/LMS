USE lms;

SELECT * FROM users;

SELECT book_id, title, author, status, borrower_id, due_date FROM books ORDER BY book_id;

SELECT * FROM v_current_loans ORDER BY due_date;


SELECT * FROM v_current_loans WHERE book_id IN (1,2,3);

SELECT t.transaction_id, b.title, b.author, t.due_date, t.renew_count
FROM transactions t
JOIN books b ON b.book_id = t.book_id
WHERE t.user_id = 1 AND t.returned = 0
ORDER BY t.due_date;