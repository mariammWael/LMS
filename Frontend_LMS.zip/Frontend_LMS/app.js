// Base URL of your C++ backend
const API_BASE = "http://localhost:18080";

// Helper to call API and handle errors
async function callApi(path, options = {}) {
    try {
        const response = await fetch(API_BASE + path, {
            method: options.method || "GET",
            headers: {
                "Content-Type": "application/json"
            },
            body: options.body ? JSON.stringify(options.body) : undefined
        });

        const text = await response.text();

        // Try to parse JSON, but if it fails just return raw text
        try {
            return JSON.parse(text);
        } catch {
            return text;
        }
    } catch (err) {
        console.error("API error:", err);
        return { error: "Network error or server not running" };
    }
}

// When the page is loaded
document.addEventListener("DOMContentLoaded", () => {

    const btnLoadBooks = document.getElementById("btnLoadBooks");
    const booksOutput = document.getElementById("booksOutput");

    const btnCheckAvailability = document.getElementById("btnCheckAvailability");
    const availabilityItem = document.getElementById("availabilityItem");
    const availabilityOutput = document.getElementById("availabilityOutput");

    const btnBorrow = document.getElementById("btnBorrow");
    const borrowItem = document.getElementById("borrowItem");
    const borrowOutput = document.getElementById("borrowOutput");

    const btnExport = document.getElementById("btnExport");
    const exportOutput = document.getElementById("exportOutput");

    // 1) Load all books
    btnLoadBooks.addEventListener("click", async () => {
        booksOutput.textContent = "Loading...";
        const data = await callApi("/books");

        // Pretty print JSON
        booksOutput.textContent = typeof data === "string"
            ? data
            : JSON.stringify(data, null, 2);
    });

    // 2) Check availability
    btnCheckAvailability.addEventListener("click", async () => {
        const itemID = availabilityItem.value.trim();
        if (!itemID) {
            availabilityOutput.textContent = "Please enter an item ID.";
            return;
        }

        availabilityOutput.textContent = "Checking...";
        const path = "/availability?item=" + encodeURIComponent(itemID);
        const data = await callApi(path);

        availabilityOutput.textContent = typeof data === "string"
            ? data
            : JSON.stringify(data, null, 2);
    });

    // 3) Borrow book
    btnBorrow.addEventListener("click", async () => {
        const itemID = borrowItem.value.trim();
        if (!itemID) {
            borrowOutput.textContent = "Please enter an item ID.";
            return;
        }

        borrowOutput.textContent = "Borrowing...";
        const path = "/borrow?item=" + encodeURIComponent(itemID);
        const data = await callApi(path);

        borrowOutput.textContent = typeof data === "string"
            ? data
            : JSON.stringify(data, null, 2);
    });

    // 4) Export
    btnExport.addEventListener("click", async () => {
        exportOutput.textContent = "Exporting...";
        const data = await callApi("/export");

        exportOutput.textContent = typeof data === "string"
            ? data
            : JSON.stringify(data, null, 2);
    });
});
