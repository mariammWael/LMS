#ifndef BOOKLOADER_H
#define BOOKLOADER_H

#include <string>
#include <vector>
#include "book.h"       // for Book
#include "inventory.h"  // for InventoryStore, ItemType

// holds what we loaded from the file
struct LoadedData {
    std::vector<Book>        books;
    std::vector<std::string> itemIDs;  // e.g. B0001, B0002, ...
};

/*
 * Read books from a text file.
 *
 * Expected format (exactly like the books.txt you sent):
 *
 *   # Books List
 *   # Format: ID | Title | Author
 *   B0001 | To Kill a Mockingbird | Harper Lee
 *   B0002 | 1984 | George Orwell
 *   ...
 *
 *  - Lines starting with '#' or empty lines are ignored.
 *  - First field  => item ID   (e.g. "B0001")
 *  - Second field => title
 *  - Third field  => author
 */
bool load_books_from_file(const std::string &filename,
                          LoadedData &outData);

// take what we loaded and add it to the inventory store
// (each itemID becomes a book in the inventory)
void add_loaded_to_inventory(const LoadedData &data,
                             InventoryStore &store,
                             int defaultQuantity);

#endif // BOOKLOADER_H
