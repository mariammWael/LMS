#include "laptop.h"
#include <string.h>

void laptop_init(Laptop *l, const char *id, const char *model)
{
    if (!l) return;

    // copy ID
    strncpy(l->laptopID, id, LAPTOP_ID_MAX);
    l->laptopID[LAPTOP_ID_MAX - 1] = '\0';

    // copy model
    strncpy(l->model, model, LAPTOP_MODEL_MAX);
    l->model[LAPTOP_MODEL_MAX - 1] = '\0';

    // default is available
    l->availabilityStatus = true;
}

bool laptop_viewAvailability(const Laptop *l)
{
    if (!l) return false;
    return l->availabilityStatus;
}

bool laptop_borrowLaptop(Laptop *l, const char *memberID)
{
    (void)memberID;  // not used yet
    if (!l) return false;
    if (!l->availabilityStatus) return false;

    l->availabilityStatus = false;
    return true;
}

void laptop_returnLaptop(Laptop *l, const char *memberID)
{
    (void)memberID;  // not used yet
    if (!l) return;

    l->availabilityStatus = true;
}
