// server.cpp  – HTTP backend for your LMS

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

#include "crow_all.h"

#include "common.h"
#include "auth.h"
#include "inventory.h"
#include "borrow.h"
#include "bookloader.h"
#include "laptop.h"
#include "StudyRoom.h"
void initializeSystem();

// ----------------------------------------------------
// Small helpers (copied from main.cpp)
// ----------------------------------------------------

static inline void trim_inplace(std::string &s)
{
    auto notSpace = [](int ch) { return !std::isspace(ch); };

    // left trim
    s.erase(s.begin(),
            std::find_if(s.begin(), s.end(), notSpace));

    // right trim
    s.erase(std::find_if(s.rbegin(), s.rend(), notSpace).base(),
            s.end());
}

// load every non-empty line from a text file into a vector
bool loadLinesFromFile(const std::string &filename,
                       std::vector<std::string> &out)
{
    out.clear();
    std::ifstream in(filename);
    if (!in.is_open()) {
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        if (!line.empty())
            out.push_back(line);
    }
    return true;
}

// build Laptop objects + inventory from lines like:
// LAP01 | Dell XPS 13
void buildLaptopsFromLines(const std::vector<std::string> &lines,
                           std::vector<Laptop> &laptops,
                           InventoryStore &store)
{
    laptops.clear();

    for (auto line : lines) {
        trim_inplace(line);
        if (line.empty()) continue;
        if (line[0] == '#') continue;

        std::stringstream ss(line);
        std::string part;
        std::vector<std::string> parts;

        while (std::getline(ss, part, '|')) {
            trim_inplace(part);
            if (!part.empty()) parts.push_back(part);
        }

        if (parts.size() < 2) continue;   // need ID and model

        const std::string &id    = parts[0];
        const std::string &model = parts[1];

        Laptop l;
        laptop_init(&l, id.c_str(), model.c_str());
        laptops.push_back(l);

        inventory_store_add(&store, id.c_str(), ITEMTYPE_LAPTOP, 1);
    }
}

// build StudyRoom objects + inventory from lines like:
// ROOM01 | Quiet Study Room 1 | 2
void buildRoomsFromLines(const std::vector<std::string> &lines,
                         std::vector<StudyRoom> &rooms,
                         InventoryStore &store)
{
    rooms.clear();

    for (auto line : lines) {
        trim_inplace(line);
        if (line.empty()) continue;
        if (line[0] == '#') continue;

        std::stringstream ss(line);
        std::string part;
        std::vector<std::string> parts;

        while (std::getline(ss, part, '|')) {
            trim_inplace(part);
            if (!part.empty()) parts.push_back(part);
        }

        if (parts.size() < 2) continue;   // at least ID + capacity/name

        const std::string &id      = parts[0];
        const std::string &capStr  = parts.back(); // last field = capacity

        int capacity = 2;
        try {
            capacity = std::stoi(capStr);
        } catch (...) {
            // keep default
        }

        StudyRoom r;
        studyRoom_init(&r, id.c_str(), capacity);
        rooms.push_back(r);

        inventory_store_add(&store, id.c_str(), ITEMTYPE_STUDYROOM, 1);
    }
}

// very simple JSON escaping for strings (no quotes/newlines in your data anyway)
static std::string json_escape(const std::string &s)
{
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (c == '\\' || c == '\"')
            out.push_back('\\');
        out.push_back(c);
    }
    return out;
}

// ----------------------------------------------------
// Global backend objects
// ----------------------------------------------------

LoadedData g_bookData;
InventoryStore g_invStore;
BorrowStore g_borrowStore;
AuthService g_auth("members.db");
std::vector<Laptop> g_laptops;
std::vector<StudyRoom> g_rooms;

// ----------------------------------------------------
// Initialize everything from files
// ----------------------------------------------------

void initializeSystem()
{
    std::cout << "Initializing LMS backend...\n";

    g_auth.load();
    inventory_store_init(&g_invStore);
    borrow_store_init(&g_borrowStore);

    // 1) Books
    load_books_from_file("books.txt", g_bookData);
    add_loaded_to_inventory(g_bookData, g_invStore, 3);   // 3 copies each

    // 2) Laptops + rooms from text files
    std::vector<std::string> laptopLines;
    std::vector<std::string> roomLines;

    if (loadLinesFromFile("laptops.txt", laptopLines)) {
        buildLaptopsFromLines(laptopLines, g_laptops, g_invStore);
    } else {
        std::cout << "laptops.txt not found; no laptops loaded.\n";
    }

    if (loadLinesFromFile("studyrooms.txt", roomLines)) {
        buildRoomsFromLines(roomLines, g_rooms, g_invStore);
    } else {
        std::cout << "studyrooms.txt not found; no rooms loaded.\n";
    }

    std::cout << "System ready.\n";
}

// ----------------------------------------------------
// Route handlers
// ----------------------------------------------------

// /login  (POST)  { "username": "...", "password": "..." }
crow::response handle_login(const crow::request &req)
{
    auto body = crow::json::load(req.body);
    if (!body.valid)
        return crow::response(400, "{\"error\":\"invalid_json\"}");

    std::string username = body.s("username");
    std::string password = body.s("password");

    int memberID = g_auth.login(username, password);

    std::string resBody = "{\"memberID\":" + std::to_string(memberID) + "}";

    if (memberID == -1)
        return crow::response(401, resBody);

    return crow::response(200, resBody);
}

// /books  (GET) → list of books with availability
crow::response handle_books(const crow::request &)
{
    std::ostringstream os;
    os << "[";

    std::size_t n = std::min(g_bookData.books.size(), g_bookData.itemIDs.size());
    for (std::size_t i = 0; i < n; ++i) {
        if (i > 0) os << ",";

        const Book &b         = g_bookData.books[i];
        const std::string &id = g_bookData.itemIDs[i];

        Inventory *inv = inventory_store_find(&g_invStore, id.c_str());
        bool available = (inv && inv->quantity > 0);

        os << "{"
           << "\"id\":\""      << json_escape(id)              << "\","
           << "\"title\":\""   << json_escape(b.title)         << "\","
           << "\"author\":\""  << json_escape(b.author)        << "\","
           << "\"available\":" << (available ? "true" : "false")
           << "}";
    }

    os << "]";
    return crow::response(200, os.str());
}

// /borrow/book (POST)  { "memberID": 1, "itemID": "B0001" }
crow::response handle_borrow_book(const crow::request &req)
{
    auto body = crow::json::load(req.body);
    if (!body.valid)
        return crow::response(400, "{\"error\":\"invalid_json\"}");

    int         memberID = body.i("memberID");
    std::string itemID   = body.s("itemID");

    Date today = date_make(1, 1, 2025);

    int borrowID = borrow_createBorrowRecord(
        &g_borrowStore,
        memberID,
        itemID.c_str(),
        today,
        today   // you can change to a proper due date
    );

    std::string resBody =
        "{\"borrowID\":" + std::to_string(borrowID) + "}";

    return crow::response(200, resBody);
}

// /laptops (GET)
crow::response handle_laptops(const crow::request &)
{
    std::ostringstream os;
    os << "[";

    for (std::size_t i = 0; i < g_laptops.size(); ++i) {
        if (i > 0) os << ",";

        const Laptop &l = g_laptops[i];

        os << "{"
           << "\"id\":\""       << json_escape(l.laptopID)           << "\","
           << "\"model\":\""    << json_escape(l.model)              << "\","
           << "\"available\":"  << (l.availabilityStatus ? "true" : "false")
           << "}";
    }

    os << "]";
    return crow::response(200, os.str());
}

// /rooms (GET)
crow::response handle_rooms(const crow::request &)
{
    std::ostringstream os;
    os << "[";

    for (std::size_t i = 0; i < g_rooms.size(); ++i) {
        if (i > 0) os << ",";

        const StudyRoom &r = g_rooms[i];

        os << "{"
           << "\"id\":\""       << json_escape(r.roomID)             << "\","
           << "\"capacity\":"   << r.capacity                         << ","
           << "\"available\":"  << (r.availabilityStatus ? "true" : "false")
           << "}";
    }

    os << "]";
    return crow::response(200, os.str());
}

// ----------------------------------------------------
// main – start HTTP server
// ----------------------------------------------------
//
// int main()
// {
//     initializeSystem();
//
//     // We can use SimpleApp directly with crow::run()
//     crow::SimpleApp app;
//
//     // POST /login
//     CROW_POST(app, "/login")([](const crow::request &req) {
//         return handle_login(req);
//     });

    // // GET /books
    // CROW_ROUTE(app, "/books")([](const crow::request &req) {
    //     return handle_books(req);
    // });
    //
    // // POST /borrow/book
    // CROW_POST(app, "/borrow/book")([](const crow::request &req) {
    //     return handle_borrow_book(req);
    // });
    //
    // // GET /laptops
    // CROW_ROUTE(app, "/laptops")([](const crow::request &req) {
    //     return handle_laptops(req);
    // });
    //
    // // GET /rooms
    // CROW_ROUTE(app, "/rooms")([](const crow::request &req) {
    //     return handle_rooms(req);
    // });

    // Start server on port 18080
//     crow::run(app, 18080);
//     return 0;
// }
