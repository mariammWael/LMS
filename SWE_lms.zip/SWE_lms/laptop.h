#ifndef LAPTOP_H
#define LAPTOP_H

#include <stdbool.h>

// Matches laptops.txt format: ID | Model
// Example line: LAP01 | Dell XPS 13

#define LAPTOP_ID_MAX    30
#define LAPTOP_MODEL_MAX 40

typedef struct {
    char laptopID[LAPTOP_ID_MAX];     // e.g. "LAP01"
    char model[LAPTOP_MODEL_MAX];     // e.g. "Dell XPS 13"
    bool availabilityStatus;          // true if available
} Laptop;

// Initialize laptop with ID and model, mark as available.
void laptop_init(Laptop *l, const char *id, const char *model);

// View availability.
bool laptop_viewAvailability(const Laptop *l);

// Borrow laptop (sets availabilityStatus = false if available).
// Returns true on success, false if already borrowed or invalid.
bool laptop_borrowLaptop(Laptop *l, const char *memberID);

// Return laptop (sets availabilityStatus = true).
void laptop_returnLaptop(Laptop *l, const char *memberID);

#endif /* LAPTOP_H */
