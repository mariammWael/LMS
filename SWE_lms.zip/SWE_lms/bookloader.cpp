#include "bookloader.h"
#include <fstream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <cctype>

// small helper to trim whitespace
static inline void trim(std::string &s)
{
    auto notSpace = [](int ch) { return !std::isspace(ch); };

    // left trim
    s.erase(s.begin(),
            std::find_if(s.begin(), s.end(), notSpace));

    // right trim
    s.erase(std::find_if(s.rbegin(), s.rend(), notSpace).base(),
            s.end());
}

// load books from a text file in the format:
//
//  # comment
//  B0001 | Title | Author
//
// Fills outData.books and outData.itemIDs.
bool load_books_from_file(const std::string &filename,
                          LoadedData &outData)
{
    outData.books.clear();
    outData.itemIDs.clear();

    std::ifstream in(filename);
    if (!in.is_open()) {
        return false;
    }

    std::string line;
    int numericID = 1;   // internal numeric ID for Book

    while (std::getline(in, line)) {
        trim(line);
        if (line.empty())          continue;      // skip blanks
        if (!line.empty() && line[0] == '#') continue; // skip comments

        // split by '|'
        std::vector<std::string> parts;
        {
            std::stringstream ss(line);
            std::string part;
            while (std::getline(ss, part, '|')) {
                trim(part);
                if (!part.empty())
                    parts.push_back(part);
            }
        }

        if (parts.size() < 3) {
            // we expect at least: ID | Title | Author
            continue;
        }

        const std::string &itemID = parts[0];  // e.g. "B0001"
        const std::string &title  = parts[1];
        const std::string &author = parts[2];

        Book b;

        // placeholders for fields we don't get from the file
        std::string isbn = "N/A";
        std::string link = "";

        // numericID is just an internal counter (1, 2, 3, ...)
        book_init(&b,
                  numericID,
                  title.c_str(),
                  author.c_str(),
                  isbn.c_str(),
                  link.c_str());

        outData.books.push_back(b);
        outData.itemIDs.push_back(itemID);

        numericID += 1;
    }

    return !outData.books.empty();
}

void add_loaded_to_inventory(const LoadedData &data,
                             InventoryStore &store,
                             int defaultQuantity)
{
    for (std::size_t i = 0; i < data.itemIDs.size(); ++i) {
        inventory_store_add(&store,
                            data.itemIDs[i].c_str(),
                            ITEMTYPE_BOOK,
                            defaultQuantity);
    }
}
