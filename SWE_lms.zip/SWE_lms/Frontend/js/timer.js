// Borrowing Timer and Expiry Notification System

let activeTimers = new Map();
let notificationShown = new Set();
const WARNING_THRESHOLD = 10 * 60; // 10 minutes in seconds
const CRITICAL_THRESHOLD = 5 * 60; // 5 minutes in seconds

async function loadActiveBorrowsWithTimers() {
    const memberID = localStorage.getItem("memberID");
    if (!memberID) {
        return;
    }

    try {
        const res = await fetch(API + "/borrowed?memberID=" + memberID);
        if (!res.ok) {
            return;
        }
        const borrows = await res.json();

        // Update active timers on page
        borrows.forEach(borrow => {
            updateTimer(borrow);
        });

        // Check for notifications
        checkExpiryNotifications(borrows);
    } catch (error) {
        console.error("Error loading borrows:", error);
    }
}

// Also update timers from activity data if available
function updateTimerFromActivity(activity) {
    if (!activity.expiryTimestamp) {
        // Calculate from dueDate if expiryTimestamp not available
        const dueDateParts = activity.dueDate.split("/");
        const dueDate = new Date(parseInt(dueDateParts[2]), parseInt(dueDateParts[1]) - 1, parseInt(dueDateParts[0]));
        activity.expiryTimestamp = Math.floor(dueDate.getTime() / 1000);
    }
    updateTimer(activity);
}

function updateTimer(borrow) {
    const timerId = `timer-${borrow.borrowID}`;
    const timerElement = document.getElementById(timerId);
    
    if (!timerElement) return;

    const now = Math.floor(Date.now() / 1000);
    const remaining = borrow.expiryTimestamp - now;

    if (remaining <= 0) {
        timerElement.innerHTML = `
            <div class="timer-value fs-4 fw-bold text-danger">EXPIRED</div>
            <div class="timer-label text-danger small fw-bold">Return immediately</div>
        `;
        return;
    }

    const days = Math.floor(remaining / 86400);
    const hours = Math.floor((remaining % 86400) / 3600);
    const minutes = Math.floor((remaining % 3600) / 60);
    const seconds = remaining % 60;

    let displayValue = "";
    let displayLabel = "";
    let colorClass = "text-primary";

    if (days > 0) {
        displayValue = days;
        displayLabel = days === 1 ? "day" : "days";
        colorClass = days <= 1 ? "text-warning" : "text-primary";
    } else if (hours > 0) {
        displayValue = hours;
        displayLabel = hours === 1 ? "hour" : "hours";
        colorClass = remaining <= WARNING_THRESHOLD ? "text-warning" : "text-primary";
    } else if (minutes > 0) {
        displayValue = minutes;
        displayLabel = minutes === 1 ? "minute" : "minutes";
        colorClass = remaining <= CRITICAL_THRESHOLD ? "text-danger" : "text-warning";
    } else {
        displayValue = seconds;
        displayLabel = seconds === 1 ? "second" : "seconds";
        colorClass = "text-danger";
    }

    timerElement.innerHTML = `
        <div class="timer-value fs-4 fw-bold ${colorClass}">${displayValue}</div>
        <div class="timer-label text-muted small">${displayLabel} remaining</div>
    `;

    // Store timer data
    activeTimers.set(borrow.borrowID, {
        remaining: remaining,
        expiryTimestamp: borrow.expiryTimestamp
    });
}

function checkExpiryNotifications(borrows) {
    const now = Math.floor(Date.now() / 1000);

    borrows.forEach(borrow => {
        const remaining = borrow.expiryTimestamp - now;
        const timerId = `notification-${borrow.borrowID}`;

        // Show warning notification at 10 minutes
        if (remaining <= WARNING_THRESHOLD && remaining > 0 && !notificationShown.has(timerId)) {
            showExpiryNotification(borrow, remaining, "warning");
            notificationShown.add(timerId);
        }

        // Show critical notification at 5 minutes
        if (remaining <= CRITICAL_THRESHOLD && remaining > 0 && !notificationShown.has(timerId + "-critical")) {
            showExpiryNotification(borrow, remaining, "critical");
            notificationShown.add(timerId + "-critical");
        }

        // Show expired notification
        if (remaining <= 0 && !notificationShown.has(timerId + "-expired")) {
            showExpiryNotification(borrow, 0, "expired");
            notificationShown.add(timerId + "-expired");
        }
    });
}

function showExpiryNotification(borrow, remaining, level) {
    let message = "";
    let type = "warning";
    let title = "";

    if (level === "expired") {
        title = "⏰ Borrowing Period Expired";
        message = `Your ${borrow.itemType.toLowerCase()} "${borrow.itemName}" borrowing period has expired. Please return it immediately.`;
        type = "danger";
    } else if (level === "critical") {
        title = "⚠️ Critical: Expiring Soon";
        const minutes = Math.floor(remaining / 60);
        message = `Your ${borrow.itemType.toLowerCase()} "${borrow.itemName}" will expire in ${minutes} minute${minutes !== 1 ? 's' : ''}. Please return or renew soon!`;
        type = "danger";
    } else {
        title = "⏳ Expiring Soon";
        const minutes = Math.floor(remaining / 60);
        message = `Your ${borrow.itemType.toLowerCase()} "${borrow.itemName}" borrowing period is about to expire in ${minutes} minute${minutes !== 1 ? 's' : ''}. Please return or renew soon.`;
        type = "warning";
    }

    // Create notification banner
    const notificationId = `expiry-notification-${borrow.borrowID}-${level}`;
    let existing = document.getElementById(notificationId);
    if (existing) {
        existing.remove();
    }

    const notification = document.createElement("div");
    notification.id = notificationId;
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    notification.style.zIndex = "10000";
    notification.style.minWidth = "500px";
    notification.style.maxWidth = "90%";
    notification.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="flex-grow-1">
                <h6 class="mb-1">${title}</h6>
                <p class="mb-0 small">${message}</p>
            </div>
            <button type="button" class="btn-close ms-3" data-bs-dismiss="alert"></button>
        </div>
    `;

    document.body.appendChild(notification);

    // Auto-dismiss after 10 seconds for warnings, 30 seconds for critical/expired
    const dismissTime = (level === "expired" || level === "critical") ? 30000 : 10000;
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.remove("show");
            setTimeout(() => notification.remove(), 150);
        }
    }, dismissTime);

    // Also show modal for critical/expired
    if (level === "critical" || level === "expired") {
        showExpiryModal(borrow, remaining, level);
    }
}

function showExpiryModal(borrow, remaining, level) {
    const modalId = `expiry-modal-${borrow.borrowID}`;
    let existing = document.getElementById(modalId);
    if (existing) {
        existing.remove();
    }

    let message = "";
    let buttonText = "Return Item";
    let buttonClass = "btn-danger";

    if (level === "expired") {
        message = `Your borrowing period for "${borrow.itemName}" has EXPIRED. Please return this item immediately to avoid penalties.`;
    } else {
        const minutes = Math.floor(remaining / 60);
        message = `Your borrowing period for "${borrow.itemName}" will expire in ${minutes} minute${minutes !== 1 ? 's' : ''}. Please return or renew this item soon!`;
        buttonText = "Return Now";
    }

    const modalHtml = `
        <div class="modal fade" id="${modalId}" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-${level === 'expired' ? 'danger' : 'warning'} text-white">
                        <h5 class="modal-title">
                            <i class="bi bi-exclamation-triangle-fill"></i> ${level === 'expired' ? 'Borrowing Period Expired' : 'Expiring Soon'}
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <i class="bi bi-clock-history fs-1 text-${level === 'expired' ? 'danger' : 'warning'}"></i>
                        </div>
                        <p class="text-center">${message}</p>
                        <div class="alert alert-info">
                            <strong>Item:</strong> ${escapeHtml(borrow.itemName)}<br>
                            <strong>Type:</strong> ${borrow.itemType}<br>
                            <strong>Due Date:</strong> ${borrow.dueDate}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn ${buttonClass}" onclick="returnItemFromModal(${borrow.borrowID}, '${escapeHtml(borrow.itemName)}')">
                            <i class="bi bi-arrow-return-left"></i> ${buttonText}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    const modal = new bootstrap.Modal(document.getElementById(modalId));
    modal.show();
}

function returnItemFromModal(borrowID, itemName) {
    // Close modal first
    const modals = document.querySelectorAll('.modal.show');
    modals.forEach(m => {
        const bsModal = bootstrap.Modal.getInstance(m);
        if (bsModal) bsModal.hide();
    });

    // Call return function
    if (typeof returnItem === 'function') {
        returnItem(borrowID, itemName);
    } else {
        // Fallback if returnItem is not available
        fetch(API + "/return", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ borrowID })
        }).then(() => {
            window.location.reload();
        });
    }
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

// Global timer update function
function startTimerSystem() {
    // Initial load
    loadActiveBorrowsWithTimers();
    
    // Update every 5 seconds
    setInterval(() => {
        loadActiveBorrowsWithTimers();
    }, 5000);
}

// Start timer updates when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startTimerSystem);
} else {
    startTimerSystem();
}

