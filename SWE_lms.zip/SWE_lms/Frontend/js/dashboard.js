// Dashboard functionality - show active borrows with countdown timers

async function loadActiveBorrows() {
    const memberID = localStorage.getItem("memberID");
    if (!memberID) {
        return;
    }

    try {
        const res = await fetch(API + "/activity?memberID=" + memberID);
        if (!res.ok) {
            return;
        }
        const activities = await res.json();

        // Filter only active (not returned) items
        const active = activities.filter(a => a.status === "Borrowed");

        const section = document.getElementById("active-borrows-section");
        const container = document.getElementById("active-borrows-list");

        if (active.length === 0) {
            section.style.display = "none";
            return;
        }

        section.style.display = "block";
        container.innerHTML = "";

        active.forEach(activity => {
            const card = createBorrowCard(activity);
            container.appendChild(card);
        });

        // Start countdown timers
        if (typeof loadActiveBorrowsWithTimers === 'function') {
            loadActiveBorrowsWithTimers();
            setInterval(loadActiveBorrowsWithTimers, 1000); // Update every second
        } else {
            updateAllTimers();
            setInterval(updateAllTimers, 1000); // Update every second
        }
    } catch (error) {
        console.error("Error loading active borrows:", error);
    }
}

function createBorrowCard(activity) {
    const card = document.createElement("div");
    card.className = "card mb-3";
    card.id = `borrow-card-${activity.borrowID}`;
    
    const icon = activity.itemType === "Book" ? "bi-book" : 
                 activity.itemType === "Laptop" ? "bi-laptop" : 
                 "bi-door-open";
    
    const color = activity.itemType === "Book" ? "primary" : 
                  activity.itemType === "Laptop" ? "success" : 
                  "info";

    // Use expiryTimestamp if available, otherwise calculate from dueDate
    let expiryTimestamp = activity.expiryTimestamp;
    if (!expiryTimestamp) {
        const dueDateParts = activity.dueDate.split("/");
        const dueDate = new Date(parseInt(dueDateParts[2]), parseInt(dueDateParts[1]) - 1, parseInt(dueDateParts[0]));
        expiryTimestamp = dueDate.getTime() / 1000; // Convert to Unix timestamp
    }

    card.innerHTML = `
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-1 text-center">
                    <i class="bi ${icon} fs-2 text-${color}"></i>
                </div>
                <div class="col-md-5">
                    <h5 class="mb-1">${escapeHtml(activity.itemName)}</h5>
                    <p class="text-muted mb-0">
                        <span class="badge bg-${color}">${activity.itemType}</span>
                        ${activity.timeSlot ? `<span class="badge bg-info ms-2">${escapeHtml(activity.timeSlot)}</span>` : ''}
                    </p>
                </div>
                <div class="col-md-3">
                    <div class="text-center">
                        <div class="countdown-timer" id="timer-${activity.borrowID}" data-expiry-timestamp="${expiryTimestamp}" data-borrow-id="${activity.borrowID}">
                            <div class="timer-display">
                                <div class="timer-value fs-4 fw-bold text-primary">--</div>
                                <div class="timer-label text-muted small">calculating...</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 text-end">
                    <div class="small text-muted mb-2">
                        <div><strong>Due:</strong> ${activity.dueDate}</div>
                        <div><strong>Borrowed:</strong> ${activity.borrowDate}</div>
                    </div>
                    <a href="activity.html" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-eye"></i> View Details
                    </a>
                </div>
            </div>
        </div>
    `;
    
    return card;
}

function updateAllTimers() {
    // Use the timer.js system if available, otherwise fallback
    if (typeof loadActiveBorrowsWithTimers === 'function') {
        loadActiveBorrowsWithTimers();
        return;
    }

    const timers = document.querySelectorAll('.countdown-timer');
    timers.forEach(timer => {
        const expiryTimestamp = parseInt(timer.getAttribute('data-expiry-timestamp'));
        const now = Math.floor(Date.now() / 1000);
        const timeRemaining = expiryTimestamp - now;

        const timerValue = timer.querySelector('.timer-value');
        const timerLabel = timer.querySelector('.timer-label');

        if (timeRemaining <= 0) {
            timerValue.textContent = "0";
            timerValue.className = "timer-value fs-4 fw-bold text-danger";
            timerLabel.textContent = "EXPIRED";
            timerLabel.className = "timer-label text-danger small fw-bold";
        } else {
            const days = Math.floor(timeRemaining / 86400);
            const hours = Math.floor((timeRemaining % 86400) / 3600);
            const minutes = Math.floor((timeRemaining % 3600) / 60);

            if (days > 0) {
                timerValue.textContent = days;
                timerValue.className = days <= 1 ? "timer-value fs-4 fw-bold text-warning" : "timer-value fs-4 fw-bold text-primary";
                timerLabel.textContent = days === 1 ? "day remaining" : "days remaining";
            } else if (hours > 0) {
                timerValue.textContent = hours;
                timerValue.className = timeRemaining <= 600 ? "timer-value fs-4 fw-bold text-danger" : "timer-value fs-4 fw-bold text-warning";
                timerLabel.textContent = hours === 1 ? "hour remaining" : "hours remaining";
            } else {
                timerValue.textContent = minutes;
                timerValue.className = "timer-value fs-4 fw-bold text-danger";
                timerLabel.textContent = minutes === 1 ? "minute remaining" : "minutes remaining";
            }
        }
    });
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

// Load active borrows when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadActiveBorrows);
} else {
    loadActiveBorrows();
}

