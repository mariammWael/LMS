async function loadActivity() {
    const memberID = localStorage.getItem("memberID");
    if (!memberID) {
        window.location.href = "login.html";
        return;
    }

    const container = document.getElementById("activity-list");
    const emptyState = document.getElementById("empty-state");
    container.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    try {
        const res = await fetch(API + "/activity?memberID=" + memberID);
        if (!res.ok) {
            throw new Error("Failed to load activity");
        }
        const activities = await res.json();

        container.innerHTML = "";

        if (activities.length === 0) {
            emptyState.style.display = "block";
            return;
        }

        emptyState.style.display = "none";

        // Group by status
        const active = activities.filter(a => a.status === "Borrowed");
        const returned = activities.filter(a => a.status === "Returned");

        if (active.length > 0) {
            container.innerHTML += '<h3 class="mb-3"><i class="bi bi-clock"></i> Active</h3>';
            active.forEach(activity => {
                container.appendChild(createActivityCard(activity, true));
            });
        }

        if (returned.length > 0) {
            container.innerHTML += '<h3 class="mb-3 mt-5"><i class="bi bi-check-circle"></i> Returned</h3>';
            returned.forEach(activity => {
                container.appendChild(createActivityCard(activity, false));
            });
        }

        // Start countdown timers for active items
        if (active.length > 0) {
            // Use timer.js system
            if (typeof updateTimerFromActivity === 'function') {
                active.forEach(activity => {
                    updateTimerFromActivity(activity);
                });
                setInterval(() => {
                    active.forEach(activity => {
                        updateTimerFromActivity(activity);
                    });
                }, 1000);
            } else {
                updateAllTimers();
                setInterval(updateAllTimers, 1000); // Update every second
            }
            
            // Check for notifications
            if (typeof checkExpiryNotifications === 'function') {
                checkExpiryNotifications(active);
            }
        }
    } catch (error) {
        container.innerHTML = '<div class="alert alert-danger">Error loading activity. Please try again later.</div>';
        console.error("Error loading activity:", error);
    }
}

function updateAllTimers() {
    // Use the timer.js system if available
    if (typeof loadActiveBorrowsWithTimers === 'function') {
        loadActiveBorrowsWithTimers();
        return;
    }

    const timers = document.querySelectorAll('.countdown-timer');
    timers.forEach(timer => {
        const expiryTimestamp = parseInt(timer.getAttribute('data-expiry-timestamp'));
        const now = Math.floor(Date.now() / 1000);
        const timeRemaining = expiryTimestamp - now;

        const timerValue = timer.querySelector('.timer-value');
        const timerLabel = timer.querySelector('.timer-label');

        if (timeRemaining <= 0) {
            timerValue.textContent = "0";
            timerValue.className = "timer-value fs-5 fw-bold text-danger";
            timerLabel.textContent = "EXPIRED";
            timerLabel.className = "timer-label text-danger small fw-bold";
        } else {
            const days = Math.floor(timeRemaining / 86400);
            const hours = Math.floor((timeRemaining % 86400) / 3600);
            const minutes = Math.floor((timeRemaining % 3600) / 60);

            if (days > 0) {
                timerValue.textContent = days;
                timerValue.className = days <= 1 ? "timer-value fs-5 fw-bold text-warning" : "timer-value fs-5 fw-bold text-primary";
                timerLabel.textContent = days === 1 ? "day remaining" : "days remaining";
            } else if (hours > 0) {
                timerValue.textContent = hours;
                timerValue.className = timeRemaining <= 600 ? "timer-value fs-5 fw-bold text-danger" : "timer-value fs-5 fw-bold text-warning";
                timerLabel.textContent = hours === 1 ? "hour remaining" : "hours remaining";
            } else {
                timerValue.textContent = minutes;
                timerValue.className = "timer-value fs-5 fw-bold text-danger";
                timerLabel.textContent = minutes === 1 ? "minute remaining" : "minutes remaining";
            }
        }
    });
}

function createActivityCard(activity, isActive) {
    const card = document.createElement("div");
    card.className = "card shadow-sm activity-card";
    
    const icon = activity.itemType === "Book" ? "bi-book" : 
                 activity.itemType === "Laptop" ? "bi-laptop" : 
                 "bi-door-open";
    
    const color = activity.itemType === "Book" ? "primary" : 
                  activity.itemType === "Laptop" ? "success" : 
                  "info";

    // Parse due date for countdown timer (only for active items)
    let timerHtml = "";
    if (isActive) {
        // Use expiryTimestamp if available, otherwise calculate
        let expiryTimestamp = activity.expiryTimestamp;
        if (!expiryTimestamp) {
            const dueDateParts = activity.dueDate.split("/");
            const dueDate = new Date(parseInt(dueDateParts[2]), parseInt(dueDateParts[1]) - 1, parseInt(dueDateParts[0]));
            expiryTimestamp = Math.floor(dueDate.getTime() / 1000);
        }
        timerHtml = `
            <div class="col-md-3">
                <div class="text-center">
                    <div class="countdown-timer" id="timer-${activity.borrowID}" data-expiry-timestamp="${expiryTimestamp}" data-borrow-id="${activity.borrowID}">
                        <div class="timer-display">
                            <div class="timer-value fs-5 fw-bold text-primary">--</div>
                            <div class="timer-label text-muted small">calculating...</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    card.innerHTML = `
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-${isActive ? '4' : '6'}">
                    <div class="d-flex align-items-center">
                        <i class="bi ${icon} fs-3 text-${color} me-3"></i>
                        <div>
                            <h5 class="mb-1">${escapeHtml(activity.itemName)}</h5>
                            <p class="text-muted mb-0">
                                <span class="badge bg-${color}">${activity.itemType}</span>
                                <span class="ms-2">ID: ${escapeHtml(activity.itemID.split('|')[0])}</span>
                                ${activity.timeSlot ? `<span class="badge bg-info ms-2">${escapeHtml(activity.timeSlot)}</span>` : ''}
                            </p>
                        </div>
                    </div>
                </div>
                ${timerHtml}
                <div class="col-md-${isActive ? '3' : '4'}">
                    <div class="small text-muted">
                        <div><strong>Borrowed:</strong> ${activity.borrowDate}</div>
                        <div><strong>Due:</strong> ${activity.dueDate}</div>
                        ${activity.returnDate ? `<div><strong>Returned:</strong> ${activity.returnDate}</div>` : ''}
                    </div>
                </div>
                <div class="col-md-2 text-end">
                    <span class="badge ${isActive ? 'bg-warning' : 'bg-success'} status-badge">
                        ${activity.status}
                    </span>
                    ${isActive ? `
                        <button class="btn btn-sm btn-outline-danger mt-2 w-100" onclick="returnItem(${activity.borrowID}, '${escapeHtml(activity.itemName)}')">
                            <i class="bi bi-arrow-return-left"></i> Return
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
    
    return card;
    
    return card;
}

async function returnItem(borrowID, itemName) {
    if (!confirm(`Return "${itemName}"?`)) {
        return;
    }

    try {
        const res = await fetch(API + "/return", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ borrowID })
        });

        const data = await res.json();

        if (!res.ok) {
            const errorMsg = data.error || "Failed to return item";
            showMessage(errorMsg, "error");
            return;
        }

        showMessage(`Successfully returned "${itemName}"!`, "success");
        loadActivity();
    } catch (error) {
        showMessage("Connection error. Please try again.", "error");
        console.error("Return error:", error);
    }
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

function showMessage(message, type) {
    const alertDiv = document.createElement("div");
    alertDiv.className = `alert alert-${type === "error" ? "danger" : "success"} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = "9999";
    alertDiv.style.minWidth = "300px";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Load activity when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadActivity);
} else {
    loadActivity();
}

