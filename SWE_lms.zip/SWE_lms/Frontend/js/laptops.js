async function loadLaptops() {
    const container = document.getElementById("laptop-list");
    container.innerHTML = '<div class="col-12 text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    try {
        const res = await fetch(API + "/laptops");
        if (!res.ok) {
            throw new Error("Failed to load laptops");
        }
        const laps = await res.json();

        container.innerHTML = "";

        if (laps.length === 0) {
            container.innerHTML = '<div class="col-12"><div class="alert alert-info">No laptops available at the moment.</div></div>';
            return;
        }

        laps.forEach(l => {
            const card = document.createElement("div");
            card.className = "col-md-4 mb-4";
            card.innerHTML = `
                <div class="card shadow-sm h-100 laptop-card">
                    <div class="card-body d-flex flex-column">
                        <div class="mb-2">
                            <i class="bi bi-laptop fs-3 text-primary"></i>
                        </div>
                        <h5 class="card-title">${escapeHtml(l.model)}</h5>
                        <p class="text-muted mb-2"><strong>ID:</strong> ${escapeHtml(l.id)}</p>
                        <p class="mb-3">
                            <span class="badge ${l.available ? 'bg-success' : 'bg-secondary'}">
                                ${l.available ? 'Available' : 'Not Available'}
                            </span>
                        </p>
                        <button 
                            class="btn btn-primary mt-auto ${!l.available ? 'disabled' : ''}"
                            onclick="borrowLaptop('${l.id}', '${escapeHtml(l.model)}')"
                            ${!l.available ? "disabled" : ""}>
                            <i class="bi bi-cart-plus"></i> Borrow
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error loading laptops. Please try again later.</div></div>';
        console.error("Error loading laptops:", error);
    }
}

async function borrowLaptop(itemID, model) {
    const memberID = localStorage.getItem("memberID");
    
    if (!memberID) {
        showMessage("Please login first", "error");
        window.location.href = "login.html";
        return;
    }

    if (!confirm(`Borrow "${model}"?`)) {
        return;
    }

    try {
        const res = await fetch(API + "/borrow/laptop", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ memberID: parseInt(memberID), itemID })
        });

        const data = await res.json();

        if (!res.ok) {
            const errorMsg = data.error || "Failed to borrow laptop";
            showMessage(errorMsg, "error");
            return;
        }

        showMessage(`Successfully borrowed "${model}"! Borrow ID: ${data.borrowID}`, "success");
        loadLaptops();
    } catch (error) {
        showMessage("Connection error. Please try again.", "error");
        console.error("Borrow error:", error);
    }
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

function showMessage(message, type) {
    const alertDiv = document.createElement("div");
    alertDiv.className = `alert alert-${type === "error" ? "danger" : "success"} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = "9999";
    alertDiv.style.minWidth = "300px";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Load laptops when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadLaptops);
} else {
    loadLaptops();
}