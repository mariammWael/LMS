if (typeof requireLogin === "function") requireLogin();

document.getElementById("navbar").innerHTML = `
<nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="dashboard.html">
      <i class="bi bi-book-half"></i> LMS
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div id="nav" class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="books.html">
            <i class="bi bi-book"></i> Books
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="laptops.html">
            <i class="bi bi-laptop"></i> Laptops
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="rooms.html">
            <i class="bi bi-door-open"></i> Study Rooms
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="activity.html">
            <i class="bi bi-clock-history"></i> My Activity
          </a>
        </li>
      </ul>

      <button class="btn btn-outline-light me-2" onclick="logout()">
        <i class="bi bi-box-arrow-right"></i> Logout
      </button>
    </div>
  </div>
</nav>
`;
