let allBooks = [];
let currentSearchQuery = "";

async function loadRecommendations() {
    const memberID = localStorage.getItem("memberID");
    if (!memberID) {
        return;
    }

    try {
        const res = await fetch(API + "/books/recommendations?memberID=" + memberID);
        if (!res.ok) {
            return;
        }
        const recommendations = await res.json();

        const section = document.getElementById("recommendations-section");
        const container = document.getElementById("recommendations-list");

        if (recommendations.length === 0) {
            section.style.display = "none";
            return;
        }

        section.style.display = "block";
        container.innerHTML = "";

        recommendations.forEach(b => {
            const card = document.createElement("div");
            card.className = "col-md-4 mb-3";
            card.innerHTML = `
                <div class="card shadow-sm h-100 book-card border-warning">
                    <div class="card-body d-flex flex-column">
                        <div class="mb-2">
                            <i class="bi bi-star-fill text-warning"></i>
                            <span class="badge bg-warning text-dark ms-2">${escapeHtml(b.reason || 'Recommended')}</span>
                        </div>
                        <div class="mb-2">
                            <i class="bi bi-book fs-3 text-primary"></i>
                        </div>
                        <h5 class="card-title">${escapeHtml(b.title)}</h5>
                        <p class="text-muted mb-2"><strong>Author:</strong> ${escapeHtml(b.author)}</p>
                        <p class="mb-3">
                            <span class="badge ${b.available ? 'bg-success' : 'bg-secondary'}">
                                ${b.available ? 'Available' : 'Not Available'}
                            </span>
                        </p>
                        <button 
                            class="btn btn-primary mt-auto ${!b.available ? 'disabled' : ''}"
                            onclick="borrowBook('${b.id}', '${escapeHtml(b.title)}')"
                            ${!b.available ? "disabled" : ""}>
                            <i class="bi bi-cart-plus"></i> Borrow
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error("Error loading recommendations:", error);
    }
}

async function loadBooks(searchQuery = "") {
    const container = document.getElementById("book-list");
    container.innerHTML = '<div class="col-12 text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    try {
        let url = API + "/books";
        if (searchQuery && searchQuery.trim() !== "") {
            url = API + "/books/search?q=" + encodeURIComponent(searchQuery);
        }
        
        const res = await fetch(url);
        if (!res.ok) {
            throw new Error("Failed to load books");
        }
        const books = await res.json();
        allBooks = books;

        container.innerHTML = "";

        if (books.length === 0) {
            container.innerHTML = '<div class="col-12"><div class="alert alert-info">No books available at the moment.</div></div>';
            return;
        }

        books.forEach(b => {
            const card = document.createElement("div");
            card.className = "col-md-4 mb-4";
            card.innerHTML = `
                <div class="card shadow-sm h-100 book-card">
                    <div class="card-body d-flex flex-column">
                        <div class="mb-2">
                            <i class="bi bi-book fs-3 text-primary"></i>
                        </div>
                        <h5 class="card-title">${escapeHtml(b.title)}</h5>
                        <p class="text-muted mb-2"><strong>Author:</strong> ${escapeHtml(b.author)}</p>
                        <p class="mb-3">
                            <span class="badge ${b.available ? 'bg-success' : 'bg-secondary'}">
                                ${b.available ? 'Available' : 'Not Available'}
                            </span>
                        </p>
                        <button 
                            class="btn btn-primary mt-auto ${!b.available ? 'disabled' : ''}"
                            onclick="borrowBook('${b.id}', '${escapeHtml(b.title)}')"
                            ${!b.available ? "disabled" : ""}>
                            <i class="bi bi-cart-plus"></i> Borrow
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error loading books. Please try again later.</div></div>';
        console.error("Error loading books:", error);
    }
}

async function borrowBook(itemID, title) {
    const memberID = localStorage.getItem("memberID");
    
    if (!memberID) {
        showMessage("Please login first", "error");
        window.location.href = "login.html";
        return;
    }

    if (!confirm(`Borrow "${title}"?`)) {
        return;
    }

    try {
        const res = await fetch(API + "/borrow/book", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ memberID: parseInt(memberID), itemID })
        });

        const data = await res.json();

        if (!res.ok) {
            const errorMsg = data.error || "Failed to borrow book";
            showMessage(errorMsg, "error");
            return;
        }

        showMessage(`Successfully borrowed "${title}"! Borrow ID: ${data.borrowID}`, "success");
        loadBooks();
    } catch (error) {
        showMessage("Connection error. Please try again.", "error");
        console.error("Borrow error:", error);
    }
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

function showMessage(message, type) {
    const alertDiv = document.createElement("div");
    alertDiv.className = `alert alert-${type === "error" ? "danger" : "success"} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = "9999";
    alertDiv.style.minWidth = "300px";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

function handleSearch(event) {
    if (event.key === 'Enter' || event.type === 'click') {
        const query = document.getElementById("search-input").value;
        currentSearchQuery = query;
        loadBooks(query);
    }
}

function clearSearch() {
    document.getElementById("search-input").value = "";
    currentSearchQuery = "";
    loadBooks();
}

// Load books and recommendations when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        loadRecommendations();
        loadBooks();
    });
} else {
    loadRecommendations();
    loadBooks();
}