function requireLogin() {
    if (!localStorage.getItem("memberID")) {
        window.location.href = "login.html";
    }
}

async function login() {
    const username = document.getElementById("user").value;
    const password = document.getElementById("pass").value;

    if (!username || !password) {
        showMessage("Please enter both username and password", "error");
        return;
    }

    try {
        const res = await fetch(API + "/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (!res.ok || data.memberID === -1) {
            showMessage("Invalid username or password", "error");
            return;
        }

        localStorage.setItem("memberID", data.memberID);
        showMessage("Login successful! Redirecting...", "success");
        setTimeout(() => {
            window.location.href = "dashboard.html";
        }, 500);
    } catch (error) {
        showMessage("Connection error. Please try again.", "error");
        console.error("Login error:", error);
    }
}

async function registerUser() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const username = document.getElementById("user").value;
    const password = document.getElementById("pass").value;

    if (!name || !email || !username || !password) {
        showMessage("Please fill in all fields", "error");
        return;
    }

    try {
        const res = await fetch(API + "/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, username, password })
        });

        const data = await res.json();

        if (!res.ok) {
            const errorMsg = data.error || "Registration failed";
            showMessage(errorMsg, "error");
            return;
        }

        showMessage("Registration successful! Redirecting to login...", "success");
        setTimeout(() => {
            window.location.href = "login.html";
        }, 1500);
    } catch (error) {
        showMessage("Connection error. Please try again.", "error");
        console.error("Registration error:", error);
    }
}

function logout() {
    localStorage.clear();
    window.location.href = "index.html";
}

function showMessage(message, type) {
    // Remove existing messages
    const existing = document.getElementById("message-alert");
    if (existing) existing.remove();

    const alertDiv = document.createElement("div");
    alertDiv.id = "message-alert";
    alertDiv.className = `alert alert-${type === "error" ? "danger" : "success"} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = "9999";
    alertDiv.style.minWidth = "300px";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}