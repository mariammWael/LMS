async function loadRooms() {
    const container = document.getElementById("room-list");
    container.innerHTML = '<div class="col-12 text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';

    try {
        const res = await fetch(API + "/rooms");
        if (!res.ok) {
            throw new Error("Failed to load rooms");
        }
        const rooms = await res.json();

        container.innerHTML = "";

        if (rooms.length === 0) {
            container.innerHTML = '<div class="col-12"><div class="alert alert-info">No study rooms available at the moment.</div></div>';
            return;
        }

        rooms.forEach((r, index) => {
            const card = document.createElement("div");
            card.className = "col-md-4 mb-4";
            
            let timeSlotsHtml = "";
            if (r.timeSlots && Array.isArray(r.timeSlots) && r.timeSlots.length > 0) {
                timeSlotsHtml = '<div class="mb-3"><small class="text-muted d-block mb-2"><strong>Available Time Slots:</strong></small>';
                r.timeSlots.forEach(slot => {
                    timeSlotsHtml += `<span class="badge bg-light text-dark me-1 mb-1">${slot}</span>`;
                });
                timeSlotsHtml += '</div>';
            }
            
            // Store time slots in a data attribute to avoid JSON escaping issues
            const timeSlotsJson = JSON.stringify(r.timeSlots || []);
            
            card.innerHTML = `
                <div class="card shadow-sm h-100 room-card">
                    <div class="card-body d-flex flex-column">
                        <div class="mb-2">
                            <i class="bi bi-door-open fs-3 text-primary"></i>
                        </div>
                        <h5 class="card-title">Room ${escapeHtml(r.id)}</h5>
                        <p class="text-muted mb-2">
                            <i class="bi bi-people"></i> <strong>Capacity:</strong> ${r.capacity} people
                        </p>
                        ${r.description ? `<p class="text-muted small mb-2">${escapeHtml(r.description)}</p>` : ''}
                        ${timeSlotsHtml}
                        <p class="mb-3">
                            <span class="badge ${r.available ? 'bg-success' : 'bg-secondary'}">
                                ${r.available ? 'Available' : 'In Use'}
                            </span>
                        </p>
                        <button 
                            class="btn btn-primary mt-auto ${!r.available ? 'disabled' : ''}"
                            data-room-id="${r.id}"
                            data-capacity="${r.capacity}"
                            data-time-slots='${timeSlotsJson}'
                            onclick="openBookingModalFromButton(this)"
                            ${!r.available ? "disabled" : ""}>
                            <i class="bi bi-calendar-check"></i> Book Room
                        </button>
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        container.innerHTML = '<div class="col-12"><div class="alert alert-danger">Error loading rooms. Please try again later.</div></div>';
        console.error("Error loading rooms:", error);
    }
}

// New function to open modal from button click
function openBookingModalFromButton(button) {
    const roomID = button.getAttribute('data-room-id');
    const capacity = parseInt(button.getAttribute('data-capacity'));
    const timeSlotsJson = button.getAttribute('data-time-slots');
    
    openBookingModal(roomID, capacity, timeSlotsJson);
}

function openBookingModal(roomID, capacity, timeSlotsJson) {
    const memberID = localStorage.getItem("memberID");
    
    if (!memberID) {
        showMessage("Please login first", "error");
        window.location.href = "login.html";
        return;
    }

    // Parse time slots from JSON string
    let timeSlots = [];
    try {
        if (typeof timeSlotsJson === 'string') {
            timeSlots = JSON.parse(timeSlotsJson);
        } else if (Array.isArray(timeSlotsJson)) {
            timeSlots = timeSlotsJson;
        }
    } catch(e) {
        console.error("Error parsing time slots:", e);
    }
    
    // Default time slots if none provided or parsing failed
    if (!timeSlots || !Array.isArray(timeSlots) || timeSlots.length === 0) {
        timeSlots = ["09:00-11:00", "11:00-13:00", "13:00-15:00", "15:00-17:00", "17:00-19:00", "19:00-21:00"];
    }

    // Create modal HTML with time slot selection
    let slotsHtml = '<div class="list-group">';
    timeSlots.forEach((slot, index) => {
        const slotId = `slot_${roomID}_${index}`;
        const safeSlot = escapeHtml(slot);
        slotsHtml += `
            <div class="form-check mb-2 p-2 border rounded hover-shadow" style="cursor: pointer;" onclick="document.getElementById('${slotId}').checked = true">
                <input class="form-check-input" type="radio" name="timeSlot" id="${slotId}" value="${safeSlot}" required>
                <label class="form-check-label w-100" for="${slotId}" style="cursor: pointer;">
                    <i class="bi bi-clock"></i> <strong>${safeSlot}</strong>
                </label>
            </div>
        `;
    });
    slotsHtml += '</div>';

    const modalHtml = `
        <div class="modal fade" id="bookingModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Book Room ${roomID}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-info mb-3">
                            <i class="bi bi-info-circle"></i> <strong>Room ${roomID}</strong><br>
                            <small>Capacity: ${capacity} people</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold mb-3"><i class="bi bi-calendar-event"></i> Select Time Slot <span class="text-danger">*</span>:</label>
                            ${slotsHtml}
                            <small class="text-muted d-block mt-2"><i class="bi bi-exclamation-circle"></i> Please select a time slot to complete your booking.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" onclick="confirmBooking('${roomID}')">Confirm Booking</button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Remove existing modal if any
    const existingModal = document.getElementById("bookingModal");
    if (existingModal) existingModal.remove();

    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById("bookingModal"));
    modal.show();
}

async function confirmBooking(roomID) {
    const memberID = localStorage.getItem("memberID");
    const selectedSlot = document.querySelector('input[name="timeSlot"]:checked');
    
    if (!selectedSlot) {
        showMessage("Please select a time slot", "error");
        return;
    }

    const timeSlot = selectedSlot.value;

    try {
        const res = await fetch(API + "/borrow/room", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ 
                memberID: parseInt(memberID), 
                itemID: roomID,
                timeSlot: timeSlot
            })
        });

        const data = await res.json();

        if (!res.ok) {
            const errorMsg = data.error || "Failed to book room";
            showMessage(errorMsg, "error");
            return;
        }

        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById("bookingModal"));
        modal.hide();

        showMessage(`Successfully booked Room ${roomID} for ${timeSlot}! Booking ID: ${data.borrowID}`, "success");
        loadRooms();
    } catch (error) {
        showMessage("Connection error. Please try again.", "error");
        console.error("Booking error:", error);
    }
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

function showMessage(message, type) {
    const alertDiv = document.createElement("div");
    alertDiv.className = `alert alert-${type === "error" ? "danger" : "success"} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = "9999";
    alertDiv.style.minWidth = "300px";
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

// Load rooms when page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadRooms);
} else {
    loadRooms();
}