#pragma once

// =========================================
// SOCKET HEADERS (CROSS-PLATFORM)
// =========================================
#ifdef _WIN32
    #define _WINSOCK_DEPRECATED_NO_WARNINGS
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "Ws2_32.lib")
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <unistd.h>
#endif


// =========================================
// STANDARD C++ HEADERS
// =========================================
#include <string>
#include <unordered_map>
#include <functional>
#include <sstream>
#include <thread>
#include <vector>
#include <iostream>
#include <map>
#include <atomic>
#include <algorithm>
#include <memory>
#include <cstring>
#include <stdexcept>
#include <cstdlib>

// =========================================
// WINSOCK INITIALIZATION (WINDOWS ONLY)
// =========================================
#ifdef _WIN32
namespace crow {
    inline void ensure_winsock_init() {
        static bool initialized = false;
        if (!initialized) {
            WSADATA wsa;
            if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
                std::cerr << "Failed to initialize Winsock\n";
                std::exit(1);
            }
            initialized = true;
        }
    }
}
#endif


// ===============================
// BASIC JSON IMPLEMENTATION
// ===============================
namespace crow {

    struct json_value {
        std::unordered_map<std::string, std::string> str_values;
        std::unordered_map<std::string, int> int_values;
        bool valid = false;

        json_value() {}

        bool has(const std::string& k) const {
            return str_values.count(k) || int_values.count(k);
        }

        std::string s(const std::string& k) const {
            if (str_values.count(k)) return str_values.at(k);
            return "";
        }

        int i(const std::string& k) const {
            if (int_values.count(k)) return int_values.at(k);
            return 0;
        }
    };

    // -------------------------------
    // JSON loader for simple LMS API
    // -------------------------------
    struct json {
        static json_value load(const std::string& body) {
            json_value j;
            j.valid = true;

            std::string key, val;
            bool readingKey = true;
            bool isString = false;

            for (size_t i = 0; i < body.size(); i++) {
                char c = body[i];

                if (c == '"') {
                    isString = !isString;
                    continue;
                }

                if (isString) {
                    if (readingKey) key += c;
                    else val += c;
                    continue;
                }

                if (c == ':') {
                    readingKey = false;
                    continue;
                }

                if (c == ',' || c == '}' || c == '{') {
                    if (!key.empty() && !val.empty()) {
                        // detect int or string
                        bool isNum = true;
                        for (char x : val) {
                            if (!isdigit(x)) isNum = false;
                        }

                        if (isNum)
                            j.int_values[key] = std::stoi(val);
                        else
                            j.str_values[key] = val;
                    }
                    key = "";
                    val = "";
                    readingKey = true;
                    continue;
                }

                if (!isspace(c)) {
                    if (readingKey) key += c;
                    else val += c;
                }
            }

            return j;
        }
    };
}
namespace crow {

    // ===============================
    // HTTP RESPONSE
    // ===============================
    struct response {
        int code = 200;
        std::string body;

        response() {}
        response(int c) : code(c) {}
        response(const std::string& b) : code(200), body(b) {}
        response(int c, const std::string& b) : code(c), body(b) {}

        void write(const std::string& s) { body += s; }

        std::string dump() const {
            std::stringstream ss;
            ss << "HTTP/1.1 " << code << " OK\r\n";
            
            // Determine content type based on body
            std::string contentType = "application/json";
            if (body.find("<!DOCTYPE") == 0 || body.find("<html") == 0) {
                contentType = "text/html";
            } else if (body.find("function") != std::string::npos && body.find(".js") != std::string::npos) {
                contentType = "application/javascript";
            } else if (body.find("@media") != std::string::npos || body.find("body {") != std::string::npos) {
                contentType = "text/css";
            }
            
            ss << "Content-Type: " << contentType << "\r\n";
            ss << "Access-Control-Allow-Origin: *\r\n";
            ss << "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n";
            ss << "Access-Control-Allow-Headers: Content-Type\r\n";
            ss << "Content-Length: " << body.size() << "\r\n";
            ss << "Connection: close\r\n\r\n";
            ss << body;
            return ss.str();
        }
    };

    // ===============================
    // HTTP REQUEST
    // ===============================
    struct request {
        std::string method;
        std::string url;
        std::string body;
        std::unordered_map<std::string, std::string> headers;
    };

}
namespace crow {

    // ======================================
    // ROUTER — maps URL + method → handler
    // ======================================
    class Router {
    public:
        using handler_t = std::function<response(const request&)>;

        std::map<std::string, handler_t> get_routes;
        std::map<std::string, handler_t> post_routes;

        void addRoute(const std::string& method,
                      const std::string& url,
                      handler_t handler)
        {
            if (method == "GET")
                get_routes[url] = handler;
            else if (method == "POST")
                post_routes[url] = handler;
        }

        response handle(const request& req) {
            // Extract base URL without query string for route matching
            std::string baseUrl = req.url;
            size_t queryPos = baseUrl.find("?");
            if (queryPos != std::string::npos) {
                baseUrl = baseUrl.substr(0, queryPos);
            }
            
            if (req.method == "GET") {
                // Try exact match first
                if (get_routes.count(req.url)) {
                    return get_routes[req.url](req);
                }
                // Try base URL match (without query string)
                if (get_routes.count(baseUrl)) {
                    return get_routes[baseUrl](req);
                }
                
                // Try to serve static files if no route matches
                if (req.url.find("/api/") != 0 && baseUrl.find("/api/") != 0) {
                    std::string filepath = "Frontend" + baseUrl;
                    if (baseUrl == "/") filepath = "Frontend/index.html";
                    
                    std::ifstream file(filepath);
                    if (file.is_open()) {
                        std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
                        response res(200, content);
                        return res;
                    }
                }
            }
            else if (req.method == "POST") {
                if (post_routes.count(req.url))
                    return post_routes[req.url](req);
                if (post_routes.count(baseUrl))
                    return post_routes[baseUrl](req);
            }
            else if (req.method == "OPTIONS") {
                // Handle CORS preflight
                response res(200, "");
                return res;
            }

            return response(404, "{\"error\":\"Not found\"}");
        }
    };

    // ======================================
    // MACRO-LIKE ROUTE DEFINER
    // ======================================
    struct SimpleApp {
        Router router;

        struct RouteBuilder {
            Router& routerRef;
            std::string method;
            std::string url;

            RouteBuilder(Router& r, const std::string& m, const std::string& u)
                : routerRef(r), method(m), url(u) {}

            template <typename Func>
            void operator()(Func f) {
                routerRef.addRoute(method, url,
                    [f](const request& req) {
                        return f(req);
                    }
                );
            }

            template <typename Func>
            void methods(Func f) {
                (*this)(f);
            }
        };

        RouteBuilder route(const std::string& url, const std::string& method) {
            return RouteBuilder(router, method, url);
        }
    };

    // Helper macros to mimic real Crow syntax
    #define CROW_ROUTE(app, url) (app).route(url, "GET")
    #define CROW_POST(app, url)  (app).route(url, "POST")
}
namespace crow {

// ===============================
// SIMPLE HTTP SERVER IMPLEMENTATION
// ===============================
class Server {
public:
    Router& router;
    int port;
    int server_fd;

    Server(Router& r, int p) : router(r), port(p), server_fd(-1) {}
    void run() {

#ifdef _WIN32
        WSADATA wsaData;
        int wsaResult = WSAStartup(MAKEWORD(2,2), &wsaData);
        if (wsaResult != 0) {
            std::cerr << "WSAStartup failed: " << wsaResult << std::endl;
            return;
        }
#endif

        server_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (server_fd == -1) {
            perror("socket");
            exit(1);
        }


        int opt = 1;
#ifdef _WIN32
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));
#else
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
#endif

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(port);

        if (bind(server_fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
            perror("bind");
            exit(1);
        }

        if (listen(server_fd, 20) < 0) {
            perror("listen");
            exit(1);
        }

        std::cout << "Server listening on port " << port << "...\n";

        while (true) {
            int client = accept(server_fd, nullptr, nullptr);
            if (client < 0) continue;
            std::thread(&Server::handleClient, this, client).detach();
        }
    }

    request parseRequest(const std::string& raw) {
        request req;
        std::stringstream ss(raw);
        std::string line;

        std::getline(ss, line);
        std::stringstream first(line);
        first >> req.method >> req.url;

        while (std::getline(ss, line) && line != "\r") {
            size_t pos = line.find(":");
            if (pos != std::string::npos) {
                std::string key = line.substr(0, pos);
                std::string val = line.substr(pos + 2);
                val.erase(std::remove(val.begin(), val.end(), '\r'), val.end());
                req.headers[key] = val;
            }
        }

        std::string body;
        while (std::getline(ss, line))
            body += line;

        req.body = body;
        return req;
    }

    void handleClient(int client_fd) {
        char buffer[4096];

        int received = recv(client_fd, buffer, 4095, 0);
        if (received <= 0) {
#ifdef _WIN32
            closesocket(client_fd);
#else
            close(client_fd);
#endif
            return;
        }

        buffer[received] = '\0';
        std::string raw(buffer);

        request req = parseRequest(raw);
        response res = router.handle(req);
        std::string out = res.dump();

        send(client_fd, out.c_str(), out.size(), 0);

#ifdef _WIN32
        closesocket(client_fd);
#else
        close(client_fd);
#endif
    }
};

// ===============================
// SimpleApp run()
// ===============================
inline void run(SimpleApp& app, int port) {
    Server server(app.router, port);
    server.run();
}

// ===============================
// AppWrapper (Crow-style API)
// ===============================
class AppWrapper {
public:
    SimpleApp app;
    int portNumber = 18080;
    bool useMultithread = false;

    AppWrapper& port(int p) {
        portNumber = p;
        return *this;
    }

    AppWrapper& multithreaded() {
        useMultithread = true;
        return *this;
    }

    void run() {
#ifdef _WIN32
        ensure_winsock_init();
#endif
        if (useMultithread) {
            std::thread serverThread([this]{
                ::crow::run(app, portNumber);
            });
            serverThread.join();
        } else {
            ::crow::run(app, portNumber);
        }
    }
};

} // namespace crow
