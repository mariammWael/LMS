#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <set>

#include "common.h"
#include "inventory.h"
#include "borrow.h"
#include "member.h"
#include "librarian.h"
#include "preferences.h"
#include "bookloader.h"
#include "auth.h"
#include "laptop.h"
#include "StudyRoom.h"
#include "export_to_excel.h"

void initializeSystem();
#include "crow_all.h"    // crow server

// These global objects are now created inside initializeSystem() in server.cpp
extern LoadedData       g_bookData;
extern InventoryStore   g_invStore;
extern BorrowStore      g_borrowStore;
extern AuthService      g_auth;
extern std::vector<Laptop>     g_laptops;
extern std::vector<StudyRoom>  g_rooms;
void initializeSystem();

// -----------------------------------------------------
// Helper function to extract ?item=xxx
// -----------------------------------------------------
std::string getQueryParam(const std::string& url, const std::string& key) {
    size_t pos = url.find(key + "=");
    if (pos == std::string::npos) return "";
    pos += key.length() + 1;
    size_t end = url.find("&", pos);
    return (end == std::string::npos) ? url.substr(pos) : url.substr(pos, end - pos);
}

// -----------------------------------------------------
// MAIN
// -----------------------------------------------------
int main()
{
    initializeSystem();     // <- loads books, laptops, rooms, members

    crow::SimpleApp app;

    // --------------------------
    // API ROUTES
    // --------------------------

    // POST /api/login
    CROW_POST(app, "/api/login")([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body.valid) {
            return crow::response(400, "{\"error\":\"invalid_json\"}");
        }

        std::string username = body.s("username");
        std::string password = body.s("password");

        int memberID = g_auth.login(username, password);
        std::string resBody = "{\"memberID\":" + std::to_string(memberID) + "}";

        return crow::response(memberID == -1 ? 401 : 200, resBody);
    });

    // POST /api/register
    CROW_POST(app, "/api/register")([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body.valid) {
            return crow::response(400, "{\"error\":\"invalid_json\"}");
        }

        std::string name = body.s("name");
        std::string email = body.s("email");
        std::string username = body.s("username");
        std::string password = body.s("password");

        int memberID = g_auth.register_user(name, email, MEMBERSHIP_STUDENT, username, password);
        
        if (memberID == -1) {
            return crow::response(400, "{\"error\":\"Username already taken\"}");
        }

        std::string resBody = "{\"memberID\":" + std::to_string(memberID) + "}";
        return crow::response(200, resBody);
    });

    // GET /api/books
    CROW_ROUTE(app, "/api/books")([](const crow::request& req) {
        std::ostringstream os;
        os << "[";

        std::size_t n = std::min(g_bookData.books.size(), g_bookData.itemIDs.size());
        for (std::size_t i = 0; i < n; ++i) {
            if (i > 0) os << ",";

            const Book &b = g_bookData.books[i];
            const std::string &id = g_bookData.itemIDs[i];

            Inventory *inv = inventory_store_find(&g_invStore, id.c_str());
            bool available = (inv && inv->quantity > 0);

            // Simple JSON escaping
            std::string title = b.title;
            std::string author = b.author;
            std::replace(title.begin(), title.end(), '"', '\'');
            std::replace(author.begin(), author.end(), '"', '\'');

            os << "{"
               << "\"id\":\"" << id << "\","
               << "\"title\":\"" << title << "\","
               << "\"author\":\"" << author << "\","
               << "\"available\":" << (available ? "true" : "false")
               << "}";
        }

        os << "]";
        return crow::response(200, os.str());
    });

    // GET /api/laptops
    CROW_ROUTE(app, "/api/laptops")([](const crow::request& req) {
        std::ostringstream os;
        os << "[";

        for (std::size_t i = 0; i < g_laptops.size(); ++i) {
            if (i > 0) os << ",";

            const Laptop &l = g_laptops[i];
            std::string model = l.model;
            std::replace(model.begin(), model.end(), '"', '\'');

            os << "{"
               << "\"id\":\"" << l.laptopID << "\","
               << "\"model\":\"" << model << "\","
               << "\"available\":" << (l.availabilityStatus ? "true" : "false")
               << "}";
        }

        os << "]";
        return crow::response(200, os.str());
    });

    // GET /api/rooms
    CROW_ROUTE(app, "/api/rooms")([](const crow::request& req) {
        std::ostringstream os;
        os << "[";

        for (std::size_t i = 0; i < g_rooms.size(); ++i) {
            if (i > 0) os << ",";

            const StudyRoom &r = g_rooms[i];
            
            // Generate time slots (9 AM to 9 PM, 2-hour slots)
            std::string timeSlots = "[";
            std::vector<std::string> slots = {"09:00-11:00", "11:00-13:00", "13:00-15:00", 
                                             "15:00-17:00", "17:00-19:00", "19:00-21:00"};
            for (size_t j = 0; j < slots.size(); ++j) {
                if (j > 0) timeSlots += ",";
                timeSlots += "\"" + slots[j] + "\"";
            }
            timeSlots += "]";

            os << "{"
               << "\"id\":\"" << r.roomID << "\","
               << "\"capacity\":" << r.capacity << ","
               << "\"available\":" << (r.availabilityStatus ? "true" : "false") << ","
               << "\"timeSlots\":" << timeSlots << ","
               << "\"description\":\"Quiet study room with " << r.capacity << " person capacity\""
               << "}";
        }

        os << "]";
        return crow::response(200, os.str());
    });

    // POST /api/borrow/book
    CROW_POST(app, "/api/borrow/book")([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body.valid) {
            return crow::response(400, "{\"error\":\"invalid_json\"}");
        }

        int memberID = body.i("memberID");
        std::string itemID = body.s("itemID");

        // Check availability
        Inventory *inv = inventory_store_find(&g_invStore, itemID.c_str());
        if (!inv || inv->quantity <= 0) {
            return crow::response(400, "{\"error\":\"Item not available\"}");
        }

        // Get current date (using system date if possible, otherwise use default)
        time_t now = time(0);
        struct tm *timeinfo = localtime(&now);
        Date today = date_make(timeinfo->tm_mday, timeinfo->tm_mon + 1, timeinfo->tm_year + 1900);
        Date dueDate = today;
        dueDate.day += 14; // 2 weeks loan period

        int borrowID = borrow_createBorrowRecord(&g_borrowStore, memberID, itemID.c_str(), today, dueDate);
        
        if (borrowID > 0) {
            inv->quantity--;
        }

        std::string resBody = "{\"borrowID\":" + std::to_string(borrowID) + "}";
        return crow::response(200, resBody);
    });

    // POST /api/borrow/laptop
    CROW_POST(app, "/api/borrow/laptop")([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body.valid) {
            return crow::response(400, "{\"error\":\"invalid_json\"}");
        }

        int memberID = body.i("memberID");
        std::string itemID = body.s("itemID");

        // Find laptop
        Laptop *laptop = nullptr;
        for (auto &l : g_laptops) {
            if (std::string(l.laptopID) == itemID) {
                laptop = &l;
                break;
            }
        }

        if (!laptop || !laptop->availabilityStatus) {
            return crow::response(400, "{\"error\":\"Laptop not available\"}");
        }

        // Get current date
        time_t now = time(0);
        struct tm *timeinfo = localtime(&now);
        Date today = date_make(timeinfo->tm_mday, timeinfo->tm_mon + 1, timeinfo->tm_year + 1900);
        Date dueDate = today;
        dueDate.day += 7; // 1 week loan period for laptops

        int borrowID = borrow_createBorrowRecord(&g_borrowStore, memberID, itemID.c_str(), today, dueDate);
        
        if (borrowID > 0) {
            laptop->availabilityStatus = false;
        }

        std::string resBody = "{\"borrowID\":" + std::to_string(borrowID) + "}";
        return crow::response(200, resBody);
    });

    // POST /api/borrow/room
    CROW_POST(app, "/api/borrow/room")([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body.valid) {
            return crow::response(400, "{\"error\":\"invalid_json\"}");
        }

        int memberID = body.i("memberID");
        std::string itemID = body.s("itemID");
        std::string timeSlot = body.s("timeSlot"); // e.g., "09:00-11:00"

        // Find room
        StudyRoom *room = nullptr;
        for (auto &r : g_rooms) {
            if (std::string(r.roomID) == itemID) {
                room = &r;
                break;
            }
        }

        if (!room || !room->availabilityStatus) {
            return crow::response(400, "{\"error\":\"Room not available\"}");
        }

        // Get current date
        time_t now = time(0);
        struct tm *timeinfo = localtime(&now);
        Date today = date_make(timeinfo->tm_mday, timeinfo->tm_mon + 1, timeinfo->tm_year + 1900);
        Date dueDate = today;
        dueDate.day += 1; // 1 day booking for rooms

        // Create itemID with time slot info: "ROOM01|09:00-11:00"
        std::string itemIDWithSlot = itemID;
        if (!timeSlot.empty()) {
            itemIDWithSlot += "|" + timeSlot;
        }

        int borrowID = borrow_createBorrowRecord(&g_borrowStore, memberID, itemIDWithSlot.c_str(), today, dueDate);
        
        if (borrowID > 0) {
            room->availabilityStatus = false;
        }

        std::string resBody = "{\"borrowID\":" + std::to_string(borrowID) + ",\"timeSlot\":\"" + timeSlot + "\"}";
        return crow::response(200, resBody);
    });

    // GET /api/export
    CROW_ROUTE(app, "/api/export")([](const crow::request& req) {
        exportAllToExcel(g_auth, g_invStore, g_borrowStore);
        return crow::response(200, "{\"status\":\"Exported\"}");
    });

    // GET /api/activity?memberID=X - Get user's activity log
    CROW_ROUTE(app, "/api/activity")([](const crow::request& req) {
        std::string memberIDStr = getQueryParam(req.url, "memberID");
        if (memberIDStr.empty()) {
            return crow::response(400, "{\"error\":\"Missing memberID\"}");
        }
        
        int memberID = std::stoi(memberIDStr);
        std::ostringstream os;
        os << "[";
        
        bool first = true;
        for (int i = 0; i < g_borrowStore.count; ++i) {
            const Borrow &b = g_borrowStore.records[i];
            if (b.memberID == memberID) {
                if (!first) os << ",";
                first = false;
                
                // Extract itemID (might have time slot appended: "ROOM01|09:00-11:00")
                std::string itemID = b.itemID;
                std::string timeSlot = "";
                size_t pipePos = itemID.find("|");
                if (pipePos != std::string::npos) {
                    timeSlot = itemID.substr(pipePos + 1);
                    itemID = itemID.substr(0, pipePos);
                }
                
                // Determine item type and name
                std::string itemType = "Unknown";
                std::string itemName = itemID;
                
                // Check if it's a book
                for (size_t j = 0; j < g_bookData.itemIDs.size(); ++j) {
                    if (g_bookData.itemIDs[j] == itemID) {
                        itemType = "Book";
                        itemName = g_bookData.books[j].title;
                        break;
                    }
                }
                
                // Check if it's a laptop
                if (itemType == "Unknown") {
                    for (const auto &l : g_laptops) {
                        if (std::string(l.laptopID) == itemID) {
                            itemType = "Laptop";
                            itemName = l.model;
                            break;
                        }
                    }
                }
                
                // Check if it's a room
                if (itemType == "Unknown") {
                    for (const auto &r : g_rooms) {
                        if (std::string(r.roomID) == itemID) {
                            itemType = "Study Room";
                            itemName = std::string("Room ") + r.roomID;
                            break;
                        }
                    }
                }
                
                // Calculate timestamps
                time_t now = time(0);
                struct tm borrow_tm = {0};
                borrow_tm.tm_year = b.borrowDate.year - 1900;
                borrow_tm.tm_mon = b.borrowDate.month - 1;
                borrow_tm.tm_mday = b.borrowDate.day;
                borrow_tm.tm_hour = 0;
                borrow_tm.tm_min = 0;
                borrow_tm.tm_sec = 0;
                time_t borrowTimestamp = mktime(&borrow_tm);
                
                struct tm due_tm = {0};
                due_tm.tm_year = b.dueDate.year - 1900;
                due_tm.tm_mon = b.dueDate.month - 1;
                due_tm.tm_mday = b.dueDate.day;
                due_tm.tm_hour = 23;
                due_tm.tm_min = 59;
                due_tm.tm_sec = 59;
                time_t expiryTimestamp = mktime(&due_tm);
                
                // Calculate remaining time in seconds
                long remainingSeconds = expiryTimestamp - now;
                if (remainingSeconds < 0) remainingSeconds = 0;
                
                os << "{"
                   << "\"borrowID\":" << b.borrowID << ","
                   << "\"itemID\":\"" << itemID << "\","
                   << "\"itemType\":\"" << itemType << "\","
                   << "\"itemName\":\"" << itemName << "\","
                   << "\"borrowDate\":\"" << b.borrowDate.day << "/" << b.borrowDate.month << "/" << b.borrowDate.year << "\","
                   << "\"dueDate\":\"" << b.dueDate.day << "/" << b.dueDate.month << "/" << b.dueDate.year << "\","
                   << "\"status\":\"" << b.status << "\","
                   << "\"borrowTimestamp\":" << borrowTimestamp << ","
                   << "\"expiryTimestamp\":" << expiryTimestamp << ","
                   << "\"remainingSeconds\":" << remainingSeconds;
                
                if (!timeSlot.empty()) {
                    os << ",\"timeSlot\":\"" << timeSlot << "\"";
                }
                
                if (b.returnDate.day > 0) {
                    os << ",\"returnDate\":\"" << b.returnDate.day << "/" << b.returnDate.month << "/" << b.returnDate.year << "\"";
                } else {
                    os << ",\"returnDate\":null";
                }
                
                os << "}";
            }
        }
        
        os << "]";
        return crow::response(200, os.str());
    });

    // POST /api/return - Return a borrowed item
    CROW_POST(app, "/api/return")([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        if (!body.valid) {
            return crow::response(400, "{\"error\":\"invalid_json\"}");
        }

        int borrowID = body.i("borrowID");
        Borrow *borrow = borrow_find_by_id(&g_borrowStore, borrowID);
        
        if (!borrow) {
            return crow::response(404, "{\"error\":\"Borrow record not found\"}");
        }
        
        if (std::string(borrow->status) == "Returned") {
            return crow::response(400, "{\"error\":\"Item already returned\"}");
        }

        // Get current date
        time_t now = time(0);
        struct tm *timeinfo = localtime(&now);
        Date today = date_make(timeinfo->tm_mday, timeinfo->tm_mon + 1, timeinfo->tm_year + 1900);
        borrow_updateReturnDate(&g_borrowStore, borrowID, today);
        
        // Restore availability
        std::string itemID = borrow->itemID;
        
        // Check if it's a book (inventory)
        Inventory *inv = inventory_store_find(&g_invStore, itemID.c_str());
        if (inv) {
            inv->quantity++;
        } else {
            // Check if it's a laptop
            for (auto &l : g_laptops) {
                if (std::string(l.laptopID) == itemID) {
                    l.availabilityStatus = true;
                    break;
                }
            }
            
            // Check if it's a room
            for (auto &r : g_rooms) {
                if (std::string(r.roomID) == itemID) {
                    r.availabilityStatus = true;
                    break;
                }
            }
        }

        return crow::response(200, "{\"status\":\"Returned successfully\"}");
    });

    // GET /api/books/recommendations?memberID=X - Get personalized book recommendations
    CROW_ROUTE(app, "/api/books/recommendations")([](const crow::request& req) {
        std::string memberIDStr = getQueryParam(req.url, "memberID");
        if (memberIDStr.empty()) {
            return crow::response(400, "{\"error\":\"Missing memberID\"}");
        }
        
        int memberID = std::stoi(memberIDStr);
        
        // Get user's borrowing history
        std::vector<std::string> borrowedAuthors;
        std::vector<std::string> borrowedTitles;
        
        for (int i = 0; i < g_borrowStore.count; ++i) {
            const Borrow &b = g_borrowStore.records[i];
            if (b.memberID == memberID && std::string(b.status) == "Borrowed") {
                std::string itemID = b.itemID;
                size_t pipePos = itemID.find("|");
                if (pipePos != std::string::npos) {
                    itemID = itemID.substr(0, pipePos);
                }
                
                // Find the book
                for (size_t j = 0; j < g_bookData.itemIDs.size(); ++j) {
                    if (g_bookData.itemIDs[j] == itemID) {
                        borrowedAuthors.push_back(g_bookData.books[j].author);
                        borrowedTitles.push_back(g_bookData.books[j].title);
                        break;
                    }
                }
            }
        }
        
        std::ostringstream os;
        os << "[";
        bool first = true;
        int count = 0;
        const int maxRecommendations = 6;
        std::set<std::string> recommendedTitles; // Track recommended book titles to avoid duplicates
        
        // Strategy 1: Recommend books by same authors (different books)
        if (!borrowedAuthors.empty()) {
            for (size_t i = 0; i < g_bookData.books.size() && count < maxRecommendations; ++i) {
                const Book &b = g_bookData.books[i];
                const std::string &id = g_bookData.itemIDs[i];
                
                // Skip if this title was already recommended
                if (recommendedTitles.find(b.title) != recommendedTitles.end()) continue;
                
                // Check if user hasn't borrowed this book yet
                bool alreadyBorrowed = false;
                for (const auto &title : borrowedTitles) {
                    if (title == b.title) {
                        alreadyBorrowed = true;
                        break;
                    }
                }
                
                if (alreadyBorrowed) continue;
                
                // Check if author matches
                bool authorMatch = false;
                for (const auto &author : borrowedAuthors) {
                    if (author == b.author) {
                        authorMatch = true;
                        break;
                    }
                }
                
                if (authorMatch) {
                    Inventory *inv = inventory_store_find(&g_invStore, id.c_str());
                    bool available = (inv && inv->quantity > 0);
                    
                    if (!first) os << ",";
                    first = false;
                    
                    std::string title = b.title;
                    std::string author = b.author;
                    std::replace(title.begin(), title.end(), '"', '\'');
                    std::replace(author.begin(), author.end(), '"', '\'');
                    
                    os << "{"
                       << "\"id\":\"" << id << "\","
                       << "\"title\":\"" << title << "\","
                       << "\"author\":\"" << author << "\","
                       << "\"available\":" << (available ? "true" : "false") << ","
                       << "\"reason\":\"Similar author\""
                       << "}";
                    recommendedTitles.insert(b.title);
                    count++;
                }
            }
        }
        
        // Strategy 2: If not enough, add popular/available books (different ones)
        if (count < maxRecommendations) {
            for (size_t i = 0; i < g_bookData.books.size() && count < maxRecommendations; ++i) {
                const Book &b = g_bookData.books[i];
                const std::string &id = g_bookData.itemIDs[i];
                
                // Skip if this title was already recommended
                if (recommendedTitles.find(b.title) != recommendedTitles.end()) continue;
                
                // Check if user hasn't borrowed this
                bool alreadyBorrowed = false;
                for (const auto &title : borrowedTitles) {
                    if (title == b.title) {
                        alreadyBorrowed = true;
                        break;
                    }
                }
                
                if (alreadyBorrowed) continue;
                
                Inventory *inv = inventory_store_find(&g_invStore, id.c_str());
                bool available = (inv && inv->quantity > 0);
                
                if (available) {
                    if (!first) os << ",";
                    first = false;
                    
                    std::string title = b.title;
                    std::string author = b.author;
                    std::replace(title.begin(), title.end(), '"', '\'');
                    std::replace(author.begin(), author.end(), '"', '\'');
                    
                    os << "{"
                       << "\"id\":\"" << id << "\","
                       << "\"title\":\"" << title << "\","
                       << "\"author\":\"" << author << "\","
                       << "\"available\":" << (available ? "true" : "false") << ","
                       << "\"reason\":\"Popular choice\""
                       << "}";
                    recommendedTitles.insert(b.title);
                    count++;
                }
            }
        }
        
        os << "]";
        return crow::response(200, os.str());
    });

    // GET /api/books/search?q=query - Search books
    CROW_ROUTE(app, "/api/books/search")([](const crow::request& req) {
        std::string query = getQueryParam(req.url, "q");
        if (query.empty()) {
            return crow::response(400, "{\"error\":\"Missing query parameter\"}");
        }
        
        // Convert query to lowercase for case-insensitive search
        std::string queryLower = query;
        std::transform(queryLower.begin(), queryLower.end(), queryLower.begin(), ::tolower);
        
        std::ostringstream os;
        os << "[";
        bool first = true;
        
        std::size_t n = std::min(g_bookData.books.size(), g_bookData.itemIDs.size());
        for (std::size_t i = 0; i < n; ++i) {
            const Book &b = g_bookData.books[i];
            std::string titleLower = b.title;
            std::string authorLower = b.author;
            std::transform(titleLower.begin(), titleLower.end(), titleLower.begin(), ::tolower);
            std::transform(authorLower.begin(), authorLower.end(), authorLower.begin(), ::tolower);
            
            if (titleLower.find(queryLower) != std::string::npos || 
                authorLower.find(queryLower) != std::string::npos) {
                if (!first) os << ",";
                first = false;
                
                const std::string &id = g_bookData.itemIDs[i];
                Inventory *inv = inventory_store_find(&g_invStore, id.c_str());
                bool available = (inv && inv->quantity > 0);
                
                std::string title = b.title;
                std::string author = b.author;
                std::replace(title.begin(), title.end(), '"', '\'');
                std::replace(author.begin(), author.end(), '"', '\'');
                
                os << "{"
                   << "\"id\":\"" << id << "\","
                   << "\"title\":\"" << title << "\","
                   << "\"author\":\"" << author << "\","
                   << "\"available\":" << (available ? "true" : "false")
                   << "}";
            }
        }
        
        os << "]";
        return crow::response(200, os.str());
    });

    // GET /api/borrowed?memberID=X - Get all borrowed items with timers
    CROW_ROUTE(app, "/api/borrowed")([](const crow::request& req) {
        std::string memberIDStr = getQueryParam(req.url, "memberID");
        if (memberIDStr.empty()) {
            return crow::response(400, "{\"error\":\"Missing memberID\"}");
        }
        
        int memberID = std::stoi(memberIDStr);
        std::ostringstream os;
        os << "[";
        
        bool first = true;
        time_t now = time(0);
        
        for (int i = 0; i < g_borrowStore.count; ++i) {
            const Borrow &b = g_borrowStore.records[i];
            if (b.memberID == memberID && std::string(b.status) == "Borrowed") {
                if (!first) os << ",";
                first = false;
                
                // Extract itemID (might have time slot appended)
                std::string itemID = b.itemID;
                std::string timeSlot = "";
                size_t pipePos = itemID.find("|");
                if (pipePos != std::string::npos) {
                    timeSlot = itemID.substr(pipePos + 1);
                    itemID = itemID.substr(0, pipePos);
                }
                
                // Determine item type and name
                std::string itemType = "Unknown";
                std::string itemName = itemID;
                
                for (size_t j = 0; j < g_bookData.itemIDs.size(); ++j) {
                    if (g_bookData.itemIDs[j] == itemID) {
                        itemType = "Book";
                        itemName = g_bookData.books[j].title;
                        break;
                    }
                }
                
                if (itemType == "Unknown") {
                    for (const auto &l : g_laptops) {
                        if (std::string(l.laptopID) == itemID) {
                            itemType = "Laptop";
                            itemName = l.model;
                            break;
                        }
                    }
                }
                
                if (itemType == "Unknown") {
                    for (const auto &r : g_rooms) {
                        if (std::string(r.roomID) == itemID) {
                            itemType = "Study Room";
                            itemName = std::string("Room ") + r.roomID;
                            break;
                        }
                    }
                }
                
                // Calculate timestamps
                struct tm borrow_tm = {0};
                borrow_tm.tm_year = b.borrowDate.year - 1900;
                borrow_tm.tm_mon = b.borrowDate.month - 1;
                borrow_tm.tm_mday = b.borrowDate.day;
                borrow_tm.tm_hour = 0;
                borrow_tm.tm_min = 0;
                borrow_tm.tm_sec = 0;
                time_t borrowTimestamp = mktime(&borrow_tm);
                
                struct tm due_tm = {0};
                due_tm.tm_year = b.dueDate.year - 1900;
                due_tm.tm_mon = b.dueDate.month - 1;
                due_tm.tm_mday = b.dueDate.day;
                due_tm.tm_hour = 23;
                due_tm.tm_min = 59;
                due_tm.tm_sec = 59;
                time_t expiryTimestamp = mktime(&due_tm);
                
                long remainingSeconds = expiryTimestamp - now;
                if (remainingSeconds < 0) remainingSeconds = 0;
                
                os << "{"
                   << "\"borrowID\":" << b.borrowID << ","
                   << "\"itemID\":\"" << itemID << "\","
                   << "\"itemType\":\"" << itemType << "\","
                   << "\"itemName\":\"" << itemName << "\","
                   << "\"borrowTimestamp\":" << borrowTimestamp << ","
                   << "\"expiryTimestamp\":" << expiryTimestamp << ","
                   << "\"remainingSeconds\":" << remainingSeconds << ","
                   << "\"borrowDate\":\"" << b.borrowDate.day << "/" << b.borrowDate.month << "/" << b.borrowDate.year << "\","
                   << "\"dueDate\":\"" << b.dueDate.day << "/" << b.dueDate.month << "/" << b.dueDate.year << "\"";
                
                if (!timeSlot.empty()) {
                    os << ",\"timeSlot\":\"" << timeSlot << "\"";
                }
                
                os << "}";
            }
        }
        
        os << "]";
        return crow::response(200, os.str());
    });

    // GET /api/status - Check database and system status
    CROW_ROUTE(app, "/api/status")([](const crow::request& req) {
        std::ostringstream os;
        os << "{"
           << "\"database\":\"connected\","
           << "\"books\":" << g_bookData.books.size() << ","
           << "\"laptops\":" << g_laptops.size() << ","
           << "\"rooms\":" << g_rooms.size() << ","
           << "\"members\":" << g_auth.getRecords().size() << ","
           << "\"borrows\":" << g_borrowStore.count
           << "}";
        return crow::response(200, os.str());
    });

    // --------------------------
    // START SERVER
    // --------------------------
    std::cout << "\n========================================\n";
    std::cout << "Starting LMS Web Server\n";
    std::cout << "Frontend: http://localhost:18080/\n";
    std::cout << "API: http://localhost:18080/api/\n";
    std::cout << "Database: " << (g_auth.getRecords().size() > 0 ? "Connected" : "Empty") << "\n";
    std::cout << "========================================\n\n";

crow::run(app, 18080);
    return 0;
}
