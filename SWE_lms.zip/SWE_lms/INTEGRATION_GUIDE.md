# Library Management System - Integration Guide

## ✅ Complete Integration Status

### Backend-Frontend Integration
- **Fully Integrated**: All frontend pages communicate with the C++ backend via REST API
- **API Base URL**: `http://localhost:18080/api`
- **CORS Enabled**: All API responses include CORS headers
- **Static File Serving**: Frontend files are served from the backend server

### Database Connection
- **Status**: ✅ Connected
- **Location**: `members.db` (SQLite database)
- **Purpose**: Stores user accounts, authentication data
- **Verification**: Check `/api/status` endpoint

## 🌐 URL Access

**IMPORTANT**: Always access the frontend through the server URL, not by opening HTML files directly!

- ✅ **Correct**: `http://localhost:18080/` (URL will change as you navigate)
- ❌ **Wrong**: Opening `Frontend/index.html` directly (file:// protocol, URL won't change)

The URL should change when navigating between pages:
- `http://localhost:18080/` → Home
- `http://localhost:18080/login.html` → Login
- `http://localhost:18080/dashboard.html` → Dashboard
- `http://localhost:18080/books.html` → Books
- `http://localhost:18080/activity.html` → Activity Log

## 🆕 New Features Added

### 1. **Search Functionality** (Books Page)
- Real-time search by title or author
- Search bar with clear button
- Case-insensitive matching

### 2. **Activity Log** (`/activity.html`)
- View all borrowed items (books, laptops, rooms)
- Separate sections for Active and Returned items
- Shows borrow dates, due dates, and return dates
- Return items directly from the activity log

### 3. **Return Functionality**
- Return books, laptops, and study rooms
- Available from Activity Log page
- Automatically restores item availability

### 4. **Enhanced Study Room Booking**
- Time slot selection (9 AM - 9 PM, 2-hour slots)
- Room capacity and description
- Modal dialog for booking confirmation
- Time slot stored with booking

### 5. **Improved Logout Button**
- More visible in navbar
- Outline style for better visibility
- Located in top-right corner

### 6. **Database Status Endpoint**
- `/api/status` - Check system status
- Shows counts of books, laptops, rooms, members, and borrows

## 📡 API Endpoints

### Authentication
- `POST /api/login` - User login
- `POST /api/register` - User registration

### Resources
- `GET /api/books` - List all books
- `GET /api/books/search?q=query` - Search books
- `GET /api/laptops` - List all laptops
- `GET /api/rooms` - List all study rooms (with time slots)

### Borrowing/Booking
- `POST /api/borrow/book` - Borrow a book
- `POST /api/borrow/laptop` - Borrow a laptop
- `POST /api/borrow/room` - Book a study room (with time slot)

### Returns
- `POST /api/return` - Return a borrowed item

### Activity
- `GET /api/activity?memberID=X` - Get user's activity log

### System
- `GET /api/status` - System status and database connection
- `GET /api/export` - Export data to Excel

## 🗄️ Database Structure

### Members Database (`members.db`)
Format: `memberID|name|email|membershipType|username|password`

### Borrow Records (In-Memory)
Stored in `BorrowStore` with fields:
- borrowID
- memberID
- itemID (with time slot for rooms: "ROOM01|09:00-11:00")
- borrowDate
- dueDate
- returnDate
- status ("Borrowed" or "Returned")

## 🚀 Running the System

1. **Compile the backend**:
   ```bash
   g++ -std=c++17 -o lms_server main.cpp server.cpp auth.cpp book.cpp bookloader.cpp borrow.cpp common.cpp export_to_excel.cpp inventory.cpp laptop.cpp librarian.cpp member.cpp preferences.cpp StudyRoom.cpp -pthread -I.
   ```

2. **Start the server**:
   ```bash
   ./lms_server
   ```

3. **Access the frontend**:
   Open browser to: `http://localhost:18080/`

## 🔍 Troubleshooting

### URL Not Changing
- **Problem**: Opening HTML files directly (file://)
- **Solution**: Always use `http://localhost:18080/`

### Connection Errors
- **Check**: Is the server running? (`ps aux | grep lms_server`)
- **Check**: Is port 18080 available?
- **Verify**: Test API with `curl http://localhost:18080/api/status`

### Database Issues
- **Location**: `members.db` in project root
- **Check**: `/api/status` endpoint shows member count
- **Note**: Database is created automatically on first registration

## 📝 Notes

- All borrow records are stored in-memory (reset on server restart)
- Study room time slots: 09:00-11:00, 11:00-13:00, 13:00-15:00, 15:00-17:00, 17:00-19:00, 19:00-21:00
- Book loan period: 14 days
- Laptop loan period: 7 days
- Study room booking: 1 day

