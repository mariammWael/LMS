#ifndef EXPORT_TO_EXCEL_H
#define EXPORT_TO_EXCEL_H

#include <string>
#include "auth.h"
#include "inventory.h"
#include "borrow.h"

// Export data to .csv files
void exportUsersToCSV(const AuthService &auth);
void exportItemsToCSV(const InventoryStore &store);
void exportTransactionsToCSV(const BorrowStore &borrowStore);

// Export everything together
void exportAllToExcel(const AuthService &auth,
                      const InventoryStore &store,
                      const BorrowStore &borrowStore);

#endif