#include "export_to_excel.h"
#include <fstream>
#include <iostream>

// helper: membership type readable string
static const char *membershipTypeToString(MembershipType t)
{
    switch (t) {
        case MEMBERSHIP_STUDENT:   return "Student";
        case MEMBERSHIP_FACULTY:   return "Faculty";
        case MEMBERSHIP_RESEARCHER:return "Researcher";
        default:                   return "Unknown";
    }
}

// helper: item type readable string
static const char *itemTypeToString(ItemType t)
{
    switch (t) {
        case ITEMTYPE_BOOK:      return "Book";
        case ITEMTYPE_LAPTOP:    return "Laptop";
        case ITEMTYPE_STUDYROOM: return "StudyRoom";
        default:                 return "Unknown";
    }
}

// ---------------- USERS ----------------
void exportUsersToCSV(const AuthService &auth)
{
    std::ofstream file("Users.csv");
    if (!file.is_open()) {
        std::cout << "Error opening Users.csv\n";
        return;
    }

    file << "member_id,name,email,membership_type,username\n";

    const std::vector<AuthRecord> &recs = auth.getRecords();

    for (const auto &u : recs) {
        file << u.memberID << ","
             << u.name << ","
             << u.email << ","
             << membershipTypeToString(u.type) << ","
             << u.username << "\n";
    }

    file.close();
    std::cout << "Users.csv exported successfully.\n";
}

// ---------------- ITEMS ----------------
void exportItemsToCSV(const InventoryStore &store)
{
    std::ofstream file("Items.csv");
    if (!file.is_open()) {
        std::cout << "Error opening Items.csv\n";
        return;
    }

    file << "item_id,item_type,quantity\n";

    for (int i = 0; i < store.count; ++i) {
        const Inventory &it = store.items[i];
        file << it.inventoryID << ","
             << itemTypeToString(it.itemType) << ","
             << it.quantity << "\n";
    }

    file.close();
    std::cout << "Items.csv exported successfully.\n";
}

// ---------------- TRANSACTIONS ----------------
void exportTransactionsToCSV(const BorrowStore &borrowStore)
{
    std::ofstream file("Transactions.csv");
    if (!file.is_open()) {
        std::cout << "Error opening Transactions.csv\n";
        return;
    }

    file << "borrow_id,member_id,item_id,borrow_date,due_date,return_date,status\n";

    for (int i = 0; i < borrowStore.count; ++i) {
        const Borrow &b = borrowStore.records[i];

        file << b.borrowID << ","
             << b.memberID << ","
             << b.itemID << ",";

        // borrow date
        file << b.borrowDate.day << "/" << b.borrowDate.month << "/" << b.borrowDate.year << ",";

        // due date
        file << b.dueDate.day << "/" << b.dueDate.month << "/" << b.dueDate.year << ",";

        // return date
        file << b.returnDate.day << "/" << b.returnDate.month << "/" << b.returnDate.year << ",";

        // status ("Borrowed", "Returned")
        file << b.status << "\n";
    }

    file.close();
    std::cout << "Transactions.csv exported successfully.\n";
}

// ---------------- EXPORT ALL ----------------
void exportAllToExcel(const AuthService &auth,
                      const InventoryStore &store,
                      const BorrowStore &borrowStore)
{
    std::cout << "\nExporting data to CSV files...\n\n";
    exportUsersToCSV(auth);
    exportItemsToCSV(store);
    exportTransactionsToCSV(borrowStore);
    std::cout << "\nAll data exported successfully!\n";
}
